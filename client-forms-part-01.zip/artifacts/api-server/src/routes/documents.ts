import { Router, type IRouter } from "express";
import { eq, desc, sql } from "drizzle-orm";
import { db, documentsTable } from "@workspace/db";
import {
  ListDocumentsQueryParams,
  ListDocumentsResponse,
  CreateDocumentBody,
  GetDocumentResponse,
  GetNextDocumentNumberQueryParams,
  GetNextDocumentNumberResponse,
  GetDocumentStatsResponse,
  GetDocumentParams,
  UpdateDocumentParams,
  UpdateDocumentBody,
  UpdateDocumentResponse,
  DeleteDocumentParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

const START_NUMBER: Record<string, number> = {
  invoice: 40000,
  quote: 1000,
};

const LOCK_NAMESPACE = 40000;

function serialize<T extends { createdAt: Date; updatedAt: Date }>(row: T) {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

type Queryer = Pick<typeof db, "select"> & { execute: typeof db.execute };

async function computeNextNumber(tx: Queryer, type: string): Promise<number> {
  const [row] = await tx
    .select({ max: sql<number>`max(${documentsTable.docNumber})` })
    .from(documentsTable)
    .where(eq(documentsTable.type, type));
  const start = START_NUMBER[type] ?? 1;
  if (row?.max == null) return start;
  return Math.max(row.max + 1, start);
}

function lockKey(type: string): number {
  return type === "invoice" ? 1 : type === "quote" ? 2 : 0;
}

router.get("/documents/next-number", async (req, res): Promise<void> => {
  const parsed = GetNextDocumentNumberQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const number = await computeNextNumber(db, parsed.data.type);
  res.json(GetNextDocumentNumberResponse.parse({ type: parsed.data.type, number }));
});

router.get("/documents/stats", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      type: documentsTable.type,
      count: sql<number>`count(*)::int`,
      max: sql<number>`max(${documentsTable.docNumber})`,
    })
    .from(documentsTable)
    .groupBy(documentsTable.type);

  const invoice = rows.find((r) => r.type === "invoice");
  const quote = rows.find((r) => r.type === "quote");

  res.json(
    GetDocumentStatsResponse.parse({
      invoiceCount: invoice?.count ?? 0,
      quoteCount: quote?.count ?? 0,
      lastInvoiceNumber: invoice?.max ?? null,
      lastQuoteNumber: quote?.max ?? null,
    }),
  );
});

router.get("/documents", async (req, res): Promise<void> => {
  const parsed = ListDocumentsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const rows = parsed.data.type
    ? await db
        .select()
        .from(documentsTable)
        .where(eq(documentsTable.type, parsed.data.type))
        .orderBy(desc(documentsTable.createdAt))
    : await db.select().from(documentsTable).orderBy(desc(documentsTable.createdAt));

  res.json(ListDocumentsResponse.parse(rows.map(serialize)));
});

router.post("/documents", async (req, res): Promise<void> => {
  const parsed = CreateDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const doc = await db.transaction(async (tx) => {
    await tx.execute(
      sql`select pg_advisory_xact_lock(${LOCK_NAMESPACE}, ${lockKey(parsed.data.type)})`,
    );
    const docNumber = await computeNextNumber(tx, parsed.data.type);
    const [created] = await tx
      .insert(documentsTable)
      .values({ ...parsed.data, docNumber })
      .returning();
    return created;
  });

  res.status(201).json(GetDocumentResponse.parse(serialize(doc)));
});

router.get("/documents/:id", async (req, res): Promise<void> => {
  const params = GetDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(eq(documentsTable.id, params.data.id));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  res.json(GetDocumentResponse.parse(serialize(doc)));
});

router.patch("/documents/:id", async (req, res): Promise<void> => {
  const params = UpdateDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [doc] = await db
    .update(documentsTable)
    .set(parsed.data)
    .where(eq(documentsTable.id, params.data.id))
    .returning();

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  res.json(UpdateDocumentResponse.parse(serialize(doc)));
});

router.delete("/documents/:id", async (req, res): Promise<void> => {
  const params = DeleteDocumentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [doc] = await db
    .delete(documentsTable)
    .where(eq(documentsTable.id, params.data.id))
    .returning();

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
