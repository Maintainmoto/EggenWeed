import express, { type Express } from "express";
import request from "supertest";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { and, eq, like } from "drizzle-orm";
import { db, jobsTable, quotesTable, pool } from "@workspace/db";
import opsRouter from "./ops";

// Integration tests for the quote -> job automation in ops.ts. These exercise
// the real Express handlers and the real DB transaction so a future refactor of
// ops.ts can't silently start creating duplicate jobs or stop creating them.
//
// Every quote/job created by these tests carries a unique marker in its `name`
// field so cleanup only ever touches this run's rows, never real data.

const MARKER = `__test_q2j_${process.pid}_${Date.now()}__`;
let seq = 0;
function uniqueName(label: string): string {
  seq += 1;
  return `${MARKER}${label}_${seq}`;
}

let app: Express;

beforeAll(() => {
  app = express();
  app.use(express.json());
  // Mount the ops router directly, bypassing auth (auth is applied at the
  // top-level router in routes/index.ts, not inside ops.ts).
  app.use(opsRouter);
});

afterEach(async () => {
  // Jobs derive their name from the originating quote, so the marker prefix
  // matches both sides.
  await db.delete(jobsTable).where(like(jobsTable.name, `${MARKER}%`));
  await db.delete(quotesTable).where(like(quotesTable.name, `${MARKER}%`));
});

afterAll(async () => {
  await pool.end();
});

async function countJobsForQuoteName(name: string): Promise<number> {
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.name, name));
  return rows.length;
}

async function jobsForQuoteName(name: string) {
  return db.select().from(jobsTable).where(eq(jobsTable.name, name));
}

describe("quote -> job automation (POST /quotes)", () => {
  it("Accepted + treatDate creates exactly 1 Open job", async () => {
    const name = uniqueName("accepted_with_date");
    const res = await request(app)
      .post("/quotes")
      .send({ name, status: "Accepted", treatDate: "2026-07-15" });
    expect(res.status).toBe(201);

    const jobs = await jobsForQuoteName(name);
    expect(jobs).toHaveLength(1);
    expect(jobs[0].jobStatus).toBe("Open");
    expect(jobs[0].treatDate).toBe("2026-07-15");
  });

  it("Draft + treatDate creates 0 jobs", async () => {
    const name = uniqueName("draft_with_date");
    const res = await request(app)
      .post("/quotes")
      .send({ name, status: "Draft", treatDate: "2026-07-15" });
    expect(res.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(0);
  });

  it("Sent + treatDate creates 0 jobs", async () => {
    const name = uniqueName("sent_with_date");
    const res = await request(app)
      .post("/quotes")
      .send({ name, status: "Sent", treatDate: "2026-07-15" });
    expect(res.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(0);
  });

  it("Rejected + treatDate creates 0 jobs", async () => {
    const name = uniqueName("rejected_with_date");
    const res = await request(app)
      .post("/quotes")
      .send({ name, status: "Rejected", treatDate: "2026-07-15" });
    expect(res.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(0);
  });

  it("Accepted with no treatDate creates 0 jobs", async () => {
    const name = uniqueName("accepted_no_date");
    const res = await request(app)
      .post("/quotes")
      .send({ name, status: "Accepted" });
    expect(res.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(0);
  });
});

describe("quote -> job automation (PATCH /quotes/:id)", () => {
  it("Draft -> Accepted (with treatDate) creates exactly 1 job", async () => {
    const name = uniqueName("draft_then_accepted");
    const createRes = await request(app)
      .post("/quotes")
      .send({ name, status: "Draft", treatDate: "2026-07-15" });
    expect(createRes.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(0);

    const id = createRes.body.id as number;
    const patchRes = await request(app)
      .patch(`/quotes/${id}`)
      .send({ status: "Accepted" });
    expect(patchRes.status).toBe(200);

    const jobs = await jobsForQuoteName(name);
    expect(jobs).toHaveLength(1);
    expect(jobs[0].jobStatus).toBe("Open");
    expect(jobs[0].treatDate).toBe("2026-07-15");
  });

  it("re-PATCHing an already-Accepted quote creates no additional job", async () => {
    const name = uniqueName("reaccept");
    const createRes = await request(app)
      .post("/quotes")
      .send({ name, status: "Accepted", treatDate: "2026-07-15" });
    expect(createRes.status).toBe(201);
    expect(await countJobsForQuoteName(name)).toBe(1);

    const id = createRes.body.id as number;
    // Re-save / re-set the same Accepted status (and a harmless field change).
    const patchRes = await request(app)
      .patch(`/quotes/${id}`)
      .send({ status: "Accepted", memo: "touched" });
    expect(patchRes.status).toBe(200);

    expect(await countJobsForQuoteName(name)).toBe(1);
  });

  it("Draft -> Accepted with no treatDate creates 0 jobs", async () => {
    const name = uniqueName("draft_accept_no_date");
    const createRes = await request(app)
      .post("/quotes")
      .send({ name, status: "Draft" });
    expect(createRes.status).toBe(201);

    const id = createRes.body.id as number;
    const patchRes = await request(app)
      .patch(`/quotes/${id}`)
      .send({ status: "Accepted" });
    expect(patchRes.status).toBe(200);

    expect(await countJobsForQuoteName(name)).toBe(0);
  });
});
