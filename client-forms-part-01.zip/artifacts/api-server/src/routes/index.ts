import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter, { requireAuth } from "./auth";
import documentsRouter from "./documents";
import opsRouter from "./ops";

const router: IRouter = Router();

// Public routes
router.use(healthRouter);
router.use(authRouter);

// Everything below requires a valid session
router.use(requireAuth, documentsRouter);
router.use(requireAuth, opsRouter);

export default router;
