import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { timingSafeEqual } from "node:crypto";
import {
  LoginBody,
  LoginResponse,
  LogoutResponse,
  GetAuthStatusResponse,
} from "@workspace/api-zod";

const AUTH_COOKIE = "eggen_auth";
const AUTH_VALUE = "ok";
const MAX_AGE_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

function isProd(): boolean {
  return process.env["NODE_ENV"] === "production";
}

function authCookieOptions() {
  return {
    httpOnly: true,
    signed: true,
    sameSite: "lax" as const,
    secure: isProd(),
    path: "/",
  };
}

function isAuthenticated(req: Request): boolean {
  return req.signedCookies?.[AUTH_COOKIE] === AUTH_VALUE;
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  if (isAuthenticated(req)) {
    next();
    return;
  }
  res.status(401).json({ error: "Authentication required" });
}

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

const router: IRouter = Router();

router.post("/auth/login", (req, res): void => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const expected = process.env["APP_PASSWORD"];
  if (!expected) {
    req.log.error("APP_PASSWORD is not configured; login is disabled");
    res.status(503).json({ error: "Login is not configured yet" });
    return;
  }

  if (!safeEqual(parsed.data.password, expected)) {
    res.status(401).json({ error: "Incorrect password" });
    return;
  }

  res.cookie(AUTH_COOKIE, AUTH_VALUE, { ...authCookieOptions(), maxAge: MAX_AGE_MS });
  res.json(LoginResponse.parse({ authenticated: true }));
});

router.post("/auth/logout", (_req, res): void => {
  res.clearCookie(AUTH_COOKIE, authCookieOptions());
  res.json(LogoutResponse.parse({ authenticated: false }));
});

router.get("/auth/me", (req, res): void => {
  res.json(GetAuthStatusResponse.parse({ authenticated: isAuthenticated(req) }));
});

export default router;
