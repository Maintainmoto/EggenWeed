import { Router, type IRouter } from "express";
import { eq, desc, asc, sql, inArray, and } from "drizzle-orm";
import {
  db,
  customersTable,
  propertiesTable,
  quotesTable,
  jobsTable,
  invoicesTable,
  routeSheetsTable,
  routeSheetStopsTable,
} from "@workspace/db";
import {
  ListCustomersResponse,
  CreateCustomerBody,
  GetCustomerResponse,
  GetCustomerParams,
  UpdateCustomerParams,
  UpdateCustomerBody,
  UpdateCustomerResponse,
  DeleteCustomerParams,
  ListPropertiesResponse,
  CreatePropertyBody,
  GetPropertyResponse,
  GetPropertyParams,
  UpdatePropertyParams,
  UpdatePropertyBody,
  UpdatePropertyResponse,
  DeletePropertyParams,
  ListQuotesResponse,
  CreateQuoteBody,
  GetQuoteResponse,
  GetQuoteParams,
  UpdateQuoteParams,
  UpdateQuoteBody,
  UpdateQuoteResponse,
  DeleteQuoteParams,
  ListJobsResponse,
  CreateJobBody,
  GetJobResponse,
  GetJobParams,
  UpdateJobParams,
  UpdateJobBody,
  UpdateJobResponse,
  DeleteJobParams,
  ListInvoicesResponse,
  CreateInvoiceBody,
  GetInvoiceResponse,
  GetInvoiceParams,
  UpdateInvoiceParams,
  UpdateInvoiceBody,
  UpdateInvoiceResponse,
  DeleteInvoiceParams,
  GetOpsStatsResponse,
  ListRouteSheetsResponse,
  CreateRouteSheetBody,
  GetRouteSheetResponse,
  GetRouteSheetParams,
  UpdateRouteSheetParams,
  UpdateRouteSheetBody,
  UpdateRouteSheetResponse,
  DeleteRouteSheetParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function serialize<T extends { createdAt: Date; updatedAt: Date }>(row: T) {
  return {
    ...row,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function serializeInvoice<
  T extends { createdAt: Date; updatedAt: Date; total: number | null; amountPaid: number | null },
>(row: T) {
  const balanceDue =
    row.total == null ? null : row.total - (row.amountPaid ?? 0);
  return { ...serialize(row), balanceDue };
}

// ---- Ops stats ----
router.get("/ops/stats", async (_req, res): Promise<void> => {
  const [[c], [p], [q], [j], [inv]] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(customersTable),
    db.select({ count: sql<number>`count(*)::int` }).from(propertiesTable),
    db.select({ count: sql<number>`count(*)::int` }).from(quotesTable),
    db.select({ count: sql<number>`count(*)::int` }).from(jobsTable),
    db.select({ count: sql<number>`count(*)::int` }).from(invoicesTable),
  ]);

  const [[openJobs], [totals]] = await Promise.all([
    db
      .select({ count: sql<number>`count(*)::int` })
      .from(jobsTable)
      .where(
        sql`${jobsTable.jobStatus} is null or lower(${jobsTable.jobStatus}) not in ('scheduled','complete','completed','closed','done','cancelled','canceled','invoiced','paid')`,
      ),
    db
      .select({
        invoiced: sql<number>`coalesce(sum(${invoicesTable.total}), 0)`,
        outstanding: sql<number>`coalesce(sum(coalesce(${invoicesTable.total}, 0) - coalesce(${invoicesTable.amountPaid}, 0)), 0)`,
      })
      .from(invoicesTable),
  ]);

  res.json(
    GetOpsStatsResponse.parse({
      customerCount: c?.count ?? 0,
      propertyCount: p?.count ?? 0,
      quoteCount: q?.count ?? 0,
      jobCount: j?.count ?? 0,
      invoiceCount: inv?.count ?? 0,
      openJobCount: openJobs?.count ?? 0,
      totalInvoiced: Number(totals?.invoiced ?? 0),
      totalOutstanding: Number(totals?.outstanding ?? 0),
    }),
  );
});

// ---- Customers ----
router.get("/customers", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(customersTable)
    .orderBy(desc(customersTable.createdAt));
  res.json(ListCustomersResponse.parse(rows.map(serialize)));
});

router.post("/customers", async (req, res): Promise<void> => {
  const parsed = CreateCustomerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [created] = await db.insert(customersTable).values(parsed.data).returning();
  res.status(201).json(GetCustomerResponse.parse(serialize(created)));
});

router.get("/customers/:id", async (req, res): Promise<void> => {
  const params = GetCustomerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select()
    .from(customersTable)
    .where(eq(customersTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  res.json(GetCustomerResponse.parse(serialize(row)));
});

router.patch("/customers/:id", async (req, res): Promise<void> => {
  const params = UpdateCustomerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateCustomerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db
    .update(customersTable)
    .set(parsed.data)
    .where(eq(customersTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  res.json(UpdateCustomerResponse.parse(serialize(row)));
});

router.delete("/customers/:id", async (req, res): Promise<void> => {
  const params = DeleteCustomerParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(customersTable)
    .where(eq(customersTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Customer not found" });
    return;
  }
  res.sendStatus(204);
});

// ---- Properties ----
router.get("/properties", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(propertiesTable)
    .orderBy(desc(propertiesTable.createdAt));
  res.json(ListPropertiesResponse.parse(rows.map(serialize)));
});

router.post("/properties", async (req, res): Promise<void> => {
  const parsed = CreatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [created] = await db.insert(propertiesTable).values(parsed.data).returning();
  res.status(201).json(GetPropertyResponse.parse(serialize(created)));
});

router.get("/properties/:id", async (req, res): Promise<void> => {
  const params = GetPropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select()
    .from(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Property not found" });
    return;
  }
  res.json(GetPropertyResponse.parse(serialize(row)));
});

router.patch("/properties/:id", async (req, res): Promise<void> => {
  const params = UpdatePropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db
    .update(propertiesTable)
    .set(parsed.data)
    .where(eq(propertiesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Property not found" });
    return;
  }
  res.json(UpdatePropertyResponse.parse(serialize(row)));
});

router.delete("/properties/:id", async (req, res): Promise<void> => {
  const params = DeletePropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Property not found" });
    return;
  }
  res.sendStatus(204);
});

// ---- Quotes ----
// Build the matching Open job values from an Accepted quote.
function jobValuesFromQuote(quote: typeof quotesTable.$inferSelect) {
  return {
    quoteId: quote.id,
    propertyId: quote.propertyId,
    name: quote.name,
    address: quote.address,
    city: quote.city,
    contact: quote.contact,
    jobDescription: quote.jobDescription,
    scheduleInstructions: quote.scheduleInstructions,
    specialInstructions: quote.specialInstructions,
    treatDate: quote.treatDate,
    total: quote.total,
    jobStatus: "Open" as const,
  };
}

router.get("/quotes", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(quotesTable)
    .orderBy(desc(quotesTable.createdAt));
  res.json(ListQuotesResponse.parse(rows.map(serialize)));
});

router.post("/quotes", async (req, res): Promise<void> => {
  const parsed = CreateQuoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const created = await db.transaction(async (tx) => {
    const [quote] = await tx
      .insert(quotesTable)
      .values(parsed.data)
      .returning();
    // Only an Accepted quote with a treatment date schedules the work, so spin
    // up a matching Open job carrying that date and the quote's details.
    if (quote.status === "Accepted" && quote.treatDate) {
      await tx.insert(jobsTable).values(jobValuesFromQuote(quote));
    }
    return quote;
  });
  res.status(201).json(GetQuoteResponse.parse(serialize(created)));
});

router.get("/quotes/:id", async (req, res): Promise<void> => {
  const params = GetQuoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select()
    .from(quotesTable)
    .where(eq(quotesTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Quote not found" });
    return;
  }
  res.json(GetQuoteResponse.parse(serialize(row)));
});

router.patch("/quotes/:id", async (req, res): Promise<void> => {
  const params = UpdateQuoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateQuoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const result = await db.transaction(async (tx) => {
    // Lock the quote row so concurrent updates serialize here; this prevents
    // two simultaneous Draft->Accepted patches from both inserting a job.
    const [prior] = await tx
      .select()
      .from(quotesTable)
      .where(eq(quotesTable.id, params.data.id))
      .for("update");
    if (!prior) return null;
    const [row] = await tx
      .update(quotesTable)
      .set(parsed.data)
      .where(eq(quotesTable.id, params.data.id))
      .returning();
    // Create the matching Open job only when the quote crosses into Accepted
    // (with a treat date). Re-saving an already-Accepted quote does nothing,
    // so no duplicate jobs are produced.
    if (
      row.status === "Accepted" &&
      row.treatDate &&
      prior.status !== "Accepted"
    ) {
      await tx.insert(jobsTable).values(jobValuesFromQuote(row));
    } else if (prior.status === "Accepted" && row.status !== "Accepted") {
      // The quote was un-accepted (moved back to Draft/Sent/Rejected). Remove
      // the matching job it created, but only while it is still Open — a job
      // that has been Scheduled/Complete/Invoiced represents real downstream
      // work and must never be dragged backward or deleted.
      await tx
        .delete(jobsTable)
        .where(
          and(
            eq(jobsTable.quoteId, row.id),
            sql`lower(${jobsTable.jobStatus}) = 'open'`,
          ),
        );
    }
    return row;
  });
  if (!result) {
    res.status(404).json({ error: "Quote not found" });
    return;
  }
  res.json(UpdateQuoteResponse.parse(serialize(result)));
});

router.delete("/quotes/:id", async (req, res): Promise<void> => {
  const params = DeleteQuoteParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const deleted = await db.transaction(async (tx) => {
    // Remove the matching job this quote created, but only while it is still
    // Open — a job that has been Scheduled/Complete/Invoiced represents real
    // downstream work and must never be dragged backward or deleted (same guard
    // as the un-accept path).
    await tx
      .delete(jobsTable)
      .where(
        and(
          eq(jobsTable.quoteId, params.data.id),
          sql`lower(${jobsTable.jobStatus}) = 'open'`,
        ),
      );
    // Any surviving advanced jobs still point at this quote; null out their
    // quoteId so the quote delete doesn't trip the foreign key while leaving the
    // real downstream work untouched.
    await tx
      .update(jobsTable)
      .set({ quoteId: null })
      .where(eq(jobsTable.quoteId, params.data.id));
    const [row] = await tx
      .delete(quotesTable)
      .where(eq(quotesTable.id, params.data.id))
      .returning();
    return row ?? null;
  });
  if (!deleted) {
    res.status(404).json({ error: "Quote not found" });
    return;
  }
  res.sendStatus(204);
});

// ---- Jobs ----
router.get("/jobs", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(jobsTable)
    .orderBy(desc(jobsTable.createdAt));
  res.json(ListJobsResponse.parse(rows.map(serialize)));
});

router.post("/jobs", async (req, res): Promise<void> => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const status = normalizeJobStatus(parsed.data.jobStatus);
  if (status === INVALID_JOB_STATUS) {
    res.status(400).json({ error: JOB_STATUS_ERROR });
    return;
  }
  const [created] = await db
    .insert(jobsTable)
    .values({ ...parsed.data, jobStatus: status ?? "Open" })
    .returning();
  res.status(201).json(GetJobResponse.parse(serialize(created)));
});

router.get("/jobs/:id", async (req, res): Promise<void> => {
  const params = GetJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.select().from(jobsTable).where(eq(jobsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Job not found" });
    return;
  }
  res.json(GetJobResponse.parse(serialize(row)));
});

router.patch("/jobs/:id", async (req, res): Promise<void> => {
  const params = UpdateJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateJobBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const values = { ...parsed.data };
  if ("jobStatus" in values) {
    const status = normalizeJobStatus(values.jobStatus);
    if (status === INVALID_JOB_STATUS) {
      res.status(400).json({ error: JOB_STATUS_ERROR });
      return;
    }
    values.jobStatus = status;
  }
  const [row] = await db
    .update(jobsTable)
    .set(values)
    .where(eq(jobsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Job not found" });
    return;
  }
  res.json(UpdateJobResponse.parse(serialize(row)));
});

router.delete("/jobs/:id", async (req, res): Promise<void> => {
  const params = DeleteJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(jobsTable)
    .where(eq(jobsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Job not found" });
    return;
  }
  res.sendStatus(204);
});

// ---- Invoices ----
router.get("/invoices", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(invoicesTable)
    .orderBy(desc(invoicesTable.createdAt));
  res.json(ListInvoicesResponse.parse(rows.map(serializeInvoice)));
});

router.post("/invoices", async (req, res): Promise<void> => {
  const parsed = CreateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const created = await db.transaction(async (tx) => {
    const [inv] = await tx.insert(invoicesTable).values(parsed.data).returning();
    if (typeof inv.jobId === "number") {
      await tx
        .update(jobsTable)
        .set({ jobStatus: "Invoiced" })
        .where(eq(jobsTable.id, inv.jobId));
    }
    return inv;
  });
  res.status(201).json(GetInvoiceResponse.parse(serializeInvoice(created)));
});

router.get("/invoices/:id", async (req, res): Promise<void> => {
  const params = GetInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select()
    .from(invoicesTable)
    .where(eq(invoicesTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  res.json(GetInvoiceResponse.parse(serializeInvoice(row)));
});

router.patch("/invoices/:id", async (req, res): Promise<void> => {
  const params = UpdateInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateInvoiceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db
    .update(invoicesTable)
    .set(parsed.data)
    .where(eq(invoicesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  res.json(UpdateInvoiceResponse.parse(serializeInvoice(row)));
});

router.delete("/invoices/:id", async (req, res): Promise<void> => {
  const params = DeleteInvoiceParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(invoicesTable)
    .where(eq(invoicesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Invoice not found" });
    return;
  }
  res.sendStatus(204);
});

// ---- Job status lifecycle ----
// Canonical lifecycle values. New jobs default to "Open"; route scheduling and
// invoicing move them forward (Open → Scheduled → Complete → Invoiced).
const JOB_STATUSES = ["Open", "Scheduled", "Complete", "Invoiced"] as const;
const INVALID_JOB_STATUS = Symbol("invalid-job-status");
const JOB_STATUS_ERROR = `jobStatus must be one of: ${JOB_STATUSES.join(", ")}`;

// Maps a free-text/blank status to its canonical form. Returns null for
// blank/omitted values (callers decide the default), the canonical value for a
// case-insensitive match, or the INVALID_JOB_STATUS sentinel for anything else.
function normalizeJobStatus(
  value: string | null | undefined,
): string | null | typeof INVALID_JOB_STATUS {
  if (value == null || value.trim() === "") return null;
  const match = JOB_STATUSES.find(
    (s) => s.toLowerCase() === value.trim().toLowerCase(),
  );
  return match ?? INVALID_JOB_STATUS;
}

// ---- Route Sheets ----
type StopWithJob = { jobId?: number | null };

// Move linked jobs forward to "Scheduled" when they land on a saved route.
// Only bumps jobs that are still Open or Scheduled, so a re-save never drags a
// Complete or Invoiced job backward.
async function scheduleJobs(
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
  stops: StopWithJob[],
) {
  const jobIds = Array.from(
    new Set(
      stops
        .map((s) => s.jobId)
        .filter((id): id is number => typeof id === "number"),
    ),
  );
  if (jobIds.length === 0) return;
  await tx
    .update(jobsTable)
    .set({ jobStatus: "Scheduled" })
    .where(
      and(
        inArray(jobsTable.id, jobIds),
        sql`(${jobsTable.jobStatus} is null or lower(${jobsTable.jobStatus}) in ('open', 'scheduled'))`,
      ),
    );
}

// The `date` column is a real Postgres date and rejects empty strings. Coerce
// blank/whitespace dates to null so a header with no date saves cleanly.
function normalizeRouteSheetHeader<T extends { date?: string | null }>(
  header: T,
): T {
  const date = header.date;
  if (typeof date === "string" && date.trim() === "") {
    return { ...header, date: null };
  }
  return header;
}

const ROUTE_LOCK_NAMESPACE = 40000;
const ROUTE_LOCK_KEY = 3;

async function computeNextRouteNumber(tx: {
  select: typeof db.select;
}): Promise<number> {
  const [row] = await tx
    .select({ max: sql<number>`max(${routeSheetsTable.routeNumber})` })
    .from(routeSheetsTable);
  return (row?.max ?? 0) + 1;
}

async function loadRouteSheet(id: number) {
  const [sheet] = await db
    .select()
    .from(routeSheetsTable)
    .where(eq(routeSheetsTable.id, id));
  if (!sheet) return null;
  const stops = await db
    .select()
    .from(routeSheetStopsTable)
    .where(eq(routeSheetStopsTable.routeSheetId, id))
    .orderBy(asc(routeSheetStopsTable.position));
  return { ...serialize(sheet), stops };
}

router.get("/route-sheets", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: routeSheetsTable.id,
      routeNumber: routeSheetsTable.routeNumber,
      date: routeSheetsTable.date,
      unit: routeSheetsTable.unit,
      sprayer: routeSheetsTable.sprayer,
      sprayer2: routeSheetsTable.sprayer2,
      typeOfRoute: routeSheetsTable.typeOfRoute,
      rigHours: routeSheetsTable.rigHours,
      notes: routeSheetsTable.notes,
      createdAt: routeSheetsTable.createdAt,
      updatedAt: routeSheetsTable.updatedAt,
      stopCount: sql<number>`(select count(*)::int from ${routeSheetStopsTable} where ${routeSheetStopsTable.routeSheetId} = ${routeSheetsTable.id})`,
    })
    .from(routeSheetsTable)
    .orderBy(desc(routeSheetsTable.createdAt));
  res.json(ListRouteSheetsResponse.parse(rows.map(serialize)));
});

router.post("/route-sheets", async (req, res): Promise<void> => {
  const parsed = CreateRouteSheetBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { stops, ...header } = parsed.data;
  const created = await db.transaction(async (tx) => {
    await tx.execute(
      sql`select pg_advisory_xact_lock(${ROUTE_LOCK_NAMESPACE}, ${ROUTE_LOCK_KEY})`,
    );
    const routeNumber = await computeNextRouteNumber(tx);
    const [sheet] = await tx
      .insert(routeSheetsTable)
      .values({ ...normalizeRouteSheetHeader(header), routeNumber })
      .returning();
    if (stops && stops.length > 0) {
      await tx.insert(routeSheetStopsTable).values(
        stops.map((s, i) => ({
          ...s,
          routeSheetId: sheet.id,
          position: s.position ?? i,
        })),
      );
      await scheduleJobs(tx, stops);
    }
    return sheet;
  });
  const full = await loadRouteSheet(created.id);
  res.status(201).json(GetRouteSheetResponse.parse(full));
});

router.get("/route-sheets/:id", async (req, res): Promise<void> => {
  const params = GetRouteSheetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const full = await loadRouteSheet(params.data.id);
  if (!full) {
    res.status(404).json({ error: "Route sheet not found" });
    return;
  }
  res.json(GetRouteSheetResponse.parse(full));
});

router.patch("/route-sheets/:id", async (req, res): Promise<void> => {
  const params = UpdateRouteSheetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateRouteSheetBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { stops, ...header } = parsed.data;
  const ok = await db.transaction(async (tx) => {
    const [sheet] = await tx
      .update(routeSheetsTable)
      .set({ ...normalizeRouteSheetHeader(header), updatedAt: new Date() })
      .where(eq(routeSheetsTable.id, params.data.id))
      .returning();
    if (!sheet) return false;
    if (stops !== undefined) {
      await tx
        .delete(routeSheetStopsTable)
        .where(eq(routeSheetStopsTable.routeSheetId, sheet.id));
      if (stops.length > 0) {
        await tx.insert(routeSheetStopsTable).values(
          stops.map((s, i) => ({
            ...s,
            routeSheetId: sheet.id,
            position: s.position ?? i,
          })),
        );
        await scheduleJobs(tx, stops);
      }
    }
    return true;
  });
  if (!ok) {
    res.status(404).json({ error: "Route sheet not found" });
    return;
  }
  const full = await loadRouteSheet(params.data.id);
  res.json(UpdateRouteSheetResponse.parse(full));
});

router.delete("/route-sheets/:id", async (req, res): Promise<void> => {
  const params = DeleteRouteSheetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .delete(routeSheetsTable)
    .where(eq(routeSheetsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Route sheet not found" });
    return;
  }
  res.sendStatus(204);
});

router.post("/route-sheets/:id/complete", async (req, res): Promise<void> => {
  const params = GetRouteSheetParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [sheet] = await db
    .select({ id: routeSheetsTable.id })
    .from(routeSheetsTable)
    .where(eq(routeSheetsTable.id, params.data.id));
  if (!sheet) {
    res.status(404).json({ error: "Route sheet not found" });
    return;
  }
  const stops = await db
    .select({ jobId: routeSheetStopsTable.jobId })
    .from(routeSheetStopsTable)
    .where(eq(routeSheetStopsTable.routeSheetId, sheet.id));
  const jobIds = Array.from(
    new Set(
      stops
        .map((s) => s.jobId)
        .filter((id): id is number => typeof id === "number"),
    ),
  );
  if (jobIds.length > 0) {
    await db
      .update(jobsTable)
      .set({ jobStatus: "Complete" })
      .where(
        and(
          inArray(jobsTable.id, jobIds),
          sql`(${jobsTable.jobStatus} is null or lower(${jobsTable.jobStatus}) <> 'invoiced')`,
        ),
      );
  }
  const full = await loadRouteSheet(sheet.id);
  res.json(GetRouteSheetResponse.parse(full));
});

export default router;
