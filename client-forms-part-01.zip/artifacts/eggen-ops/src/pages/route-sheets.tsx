import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Loader2, Route as RouteIcon } from "lucide-react";
import {
  useListRouteSheets,
  useDeleteRouteSheet,
  getListRouteSheetsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

function formatDate(value?: string | null) {
  if (!value) return "—";
  const d = new Date(value + "T00:00:00");
  if (isNaN(d.getTime())) return value;
  return d.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function RouteSheets() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data, isLoading } = useListRouteSheets();
  const del = useDeleteRouteSheet({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListRouteSheetsQueryKey() });
        toast({ title: "Route sheet deleted" });
      },
    },
  });

  const rows = data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Route Sheets</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Build and print daily route sheets for the crew.
          </p>
        </div>
        <Link href="/route-sheets/new">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Route Sheet
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">All Route Sheets</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-12 flex justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : rows.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground">
              <RouteIcon className="h-8 w-8 mx-auto mb-3 opacity-40" />
              <p>No route sheets yet.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Route #</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>Sprayer(s)</TableHead>
                  <TableHead>Type of Route</TableHead>
                  <TableHead className="text-right">Stops</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => {
                  const sprayers = [r.sprayer, r.sprayer2]
                    .filter(Boolean)
                    .join(", ");
                  return (
                    <TableRow
                      key={r.id}
                      className="cursor-pointer"
                      onClick={() => setLocation(`/route-sheets/${r.id}`)}
                    >
                      <TableCell className="font-semibold tabular-nums">
                        {r.routeNumber != null ? `#${r.routeNumber}` : "—"}
                      </TableCell>
                      <TableCell className="font-medium">
                        {formatDate(r.date)}
                      </TableCell>
                      <TableCell>{r.unit || "—"}</TableCell>
                      <TableCell>{sprayers || "—"}</TableCell>
                      <TableCell>{r.typeOfRoute || "—"}</TableCell>
                      <TableCell className="text-right">{r.stopCount}</TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (
                              confirm("Delete this route sheet? This cannot be undone.")
                            ) {
                              del.mutate({ id: r.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
