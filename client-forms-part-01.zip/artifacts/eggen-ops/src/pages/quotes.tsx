import { useRef, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas-pro";
import {
  useListQuotes,
  useCreateQuote,
  useUpdateQuote,
  useDeleteQuote,
  useGetQuote,
  useListProperties,
  useListCustomers,
  useCreateCustomer,
  useCreateProperty,
  getListQuotesQueryKey,
  getGetQuoteQueryKey,
  getListCustomersQueryKey,
  getListPropertiesQueryKey,
  getListJobsQueryKey,
  type Quote,
} from "@workspace/api-client-react";
import {
  CrudList,
  CrudDetail,
  StatusBadge,
  type FieldSpec,
  type Column,
} from "@/components/crud";
import { Printer, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate, displayText } from "@/lib/format";
import Logo from "@assets/Logo_1781823781016.png";

const customerQuickFields: FieldSpec[] = [
  { name: "customerName", label: "Customer Name", full: true },
  {
    name: "customerType",
    label: "Type",
    type: "select",
    options: [
      { value: "Commercial", label: "Commercial" },
      { value: "Residential", label: "Residential" },
    ],
  },
  { name: "contactName", label: "Contact Name" },
  { name: "contactNumber", label: "Contact Number" },
  { name: "address", label: "Address", full: true },
  { name: "city", label: "City" },
  { name: "state", label: "State", defaultValue: "AZ" },
  { name: "zip", label: "ZIP" },
];

function propertyQuickFields(
  customerOptions: { value: string; label: string }[],
): FieldSpec[] {
  return [
    {
      name: "customerId",
      label: "Customer",
      type: "relation",
      nameField: "customerName",
      options: customerOptions,
    },
    { name: "name", label: "Property Name" },
    { name: "status", label: "Status" },
    { name: "streetAddress", label: "Street Address", full: true },
    { name: "unit", label: "Unit" },
    { name: "city", label: "City" },
    { name: "state", label: "State", defaultValue: "AZ" },
    { name: "zip", label: "ZIP" },
    { name: "phone", label: "Phone" },
    { name: "contact", label: "Contact" },
  ];
}

function useFields(): FieldSpec[] {
  const qc = useQueryClient();
  const { data: properties } = useListProperties();
  const { data: customers } = useListCustomers();
  const createCustomer = useCreateCustomer({
    mutation: {
      onSuccess: () =>
        qc.invalidateQueries({ queryKey: getListCustomersQueryKey() }),
    },
  });
  const createProperty = useCreateProperty({
    mutation: {
      onSuccess: () =>
        qc.invalidateQueries({ queryKey: getListPropertiesQueryKey() }),
    },
  });

  const customerOptions = (customers ?? []).map((c) => ({
    value: String(c.id),
    label: c.customerName ?? `#${c.id}`,
  }));

  return [
    {
      name: "customerId",
      label: "Customer",
      type: "relation",
      nameField: "customerName",
      options: customerOptions,
      quickCreate: {
        title: "New Customer",
        fields: customerQuickFields,
        onCreate: async (data) => {
          const res = await createCustomer.mutateAsync({ data });
          return { id: res.id, label: res.customerName ?? `#${res.id}` };
        },
      },
      onSelect: (id) => {
        const c = (customers ?? []).find((x) => x.id === id);
        const extra: Record<string, unknown> = {
          propertyId: null,
          propertyName: null,
        };
        if (c) {
          if (c.address) extra.billToAddress = c.address;
          if (c.city) extra.billToCity = c.city;
          if (c.zip) extra.billToZip = c.zip;
          if (c.contactNumber) extra.billToPhone = c.contactNumber;
        }
        return extra;
      },
    },
    {
      name: "propertyId",
      label: "Property",
      type: "relation",
      nameField: "propertyName",
      options: (properties ?? []).map((p) => ({
        value: String(p.id),
        label: p.name ?? `#${p.id}`,
      })),
      optionsFor: (values) => {
        const cid =
          values.customerId != null ? Number(values.customerId) : null;
        return (properties ?? [])
          .filter((p) => cid == null || p.customerId === cid)
          .map((p) => ({ value: String(p.id), label: p.name ?? `#${p.id}` }));
      },
      quickCreate: {
        title: "New Property",
        fields: propertyQuickFields(customerOptions),
        onCreate: async (data) => {
          const res = await createProperty.mutateAsync({ data });
          return {
            id: res.id,
            label: res.name ?? `#${res.id}`,
            merge: {
              name: res.name ?? null,
              address:
                [res.streetAddress, res.unit].filter(Boolean).join(" ") || null,
              city: res.city ?? null,
              state: res.state ?? null,
              zip: res.zip ?? null,
            },
          };
        },
      },
      quickCreateInitial: (values) => ({
        customerId: values.customerId ?? null,
        customerName: values.customerName ?? null,
      }),
      onSelect: (id) => {
        const p = (properties ?? []).find((x) => x.id === id);
        if (!p) return;
        return {
          name: p.name ?? null,
          address: [p.streetAddress, p.unit].filter(Boolean).join(" ") || null,
          city: p.city ?? null,
          state: p.state ?? null,
          zip: p.zip ?? null,
        };
      },
    },
    { name: "name", label: "Name" },
    {
      name: "status",
      label: "Status",
      type: "select",
      defaultValue: "Draft",
      options: [
        { value: "Draft", label: "Draft" },
        { value: "Sent", label: "Sent" },
        { value: "Accepted", label: "Accepted" },
        { value: "Rejected", label: "Rejected" },
      ],
    },
    { name: "total", label: "Total", type: "number", currency: true },
    { name: "address", label: "Address", full: true },
    { name: "city", label: "City" },
    { name: "state", label: "State", defaultValue: "AZ" },
    { name: "zip", label: "ZIP" },
    { name: "phoneNumber", label: "Phone" },
    { name: "email", label: "Email" },
    { name: "contact", label: "Contact" },
    { name: "salesPerson", label: "Sales Person" },
    { name: "billToAddress", label: "Bill To Address" },
    { name: "billToCity", label: "Bill To City" },
    { name: "billToZip", label: "Bill To ZIP" },
    { name: "billToPhone", label: "Bill To Phone" },
    { name: "checkNumber", label: "Check Number" },
    { name: "idNumber", label: "ID Number" },
    { name: "poNumber", label: "PO Number" },
    { name: "grid", label: "Grid" },
    { name: "ratio", label: "Ratio", type: "number" },
    { name: "time", label: "Time" },
    { name: "confirm", label: "Confirm" },
    { name: "estimateDate", label: "Estimate Date", type: "date" },
    { name: "treatDate", label: "Treat Date", type: "date" },
    { name: "jobDescription", label: "Job Description", type: "textarea" },
    { name: "memo", label: "Memo", type: "textarea" },
    { name: "scheduleInstructions", label: "Schedule Instructions", type: "textarea" },
    { name: "specialInstructions", label: "Special Instructions", type: "textarea" },
  ];
}

const statusMap: Record<string, string> = {
  draft: "bg-muted text-muted-foreground",
  sent: "bg-secondary/20 text-secondary",
  accepted: "bg-primary/15 text-primary",
  rejected: "bg-destructive/15 text-destructive",
};

const columns: Column<Quote>[] = [
  { key: "id", header: "Quote #", render: (r) => `#${r.id}` },
  { key: "name", header: "Name" },
  { key: "customerName", header: "Customer", filterable: true },
  { key: "propertyName", header: "Property", filterable: true },
  {
    key: "total",
    header: "Total",
    render: (r) => formatCurrency(r.total),
  },
  {
    key: "status",
    header: "Status",
    render: (r) => <StatusBadge value={r.status} map={statusMap} />,
    filterable: true,
  },
];

function useMutations() {
  const qc = useQueryClient();
  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListQuotesQueryKey() });
    // Accepting a quote (with a treat date) creates a matching Open job
    // server-side, so refresh the jobs list too — otherwise the new job won't
    // appear in the Jobs page or the route builder's job picker.
    qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetQuoteQueryKey(id) });
  };
  const create = useCreateQuote({ mutation: { onSuccess: () => invalidate() } });
  const update = useUpdateQuote({ mutation: { onSuccess: (d) => invalidate(d.id) } });
  const del = useDeleteQuote({ mutation: { onSuccess: () => invalidate() } });
  return { create, update, del };
}

export function Quotes() {
  const { data, isLoading } = useListQuotes();
  const fields = useFields();
  const { create, update, del } = useMutations();

  return (
    <CrudList
      title="Quotes"
      singular="Quote"
      rows={data ?? []}
      isLoading={isLoading}
      columns={columns}
      fields={fields}
      searchKeys={["name", "customerName", "propertyName", "city", "contact"]}
      detailPath="/quotes"
      onCreate={(d) => create.mutateAsync({ data: d })}
      onUpdate={(id, d) => update.mutateAsync({ id, data: d })}
      onDelete={(id) => del.mutateAsync({ id })}
      isMutating={create.isPending || update.isPending}
    />
  );
}

function emailHref(q: Quote): string {
  const ref = `Quote #${q.id}`;
  const lines = [
    `${ref}`,
    q.customerName ? `Customer: ${q.customerName}` : null,
    q.propertyName ? `Property: ${q.propertyName}` : null,
    q.estimateDate ? `Estimate Date: ${formatDate(q.estimateDate)}` : null,
    q.treatDate ? `Treat Date: ${formatDate(q.treatDate)}` : null,
    q.total != null ? `Total: ${formatCurrency(q.total)}` : null,
    "",
    "Please find your quotation attached as a PDF.",
    "",
    "Thank you,",
    "Eggen Weed Control",
  ].filter((l) => l != null);
  const params = new URLSearchParams({
    subject: `${ref} — Eggen Weed Control`,
    body: lines.join("\n"),
  });
  const to = q.email ? encodeURIComponent(q.email) : "";
  return `mailto:${to}?${params.toString()}`;
}

export function QuoteDetail({ id }: { id: number }) {
  const { data, isLoading } = useGetQuote(id, {
    query: { enabled: !!id, queryKey: getGetQuoteQueryKey(id) },
  });
  const fields = useFields();
  const { update, del } = useMutations();
  const { toast } = useToast();
  const pdfRef = useRef<HTMLDivElement>(null);

  const handleEmail = async () => {
    const el = pdfRef.current;
    if (!el || !data) return;
    try {
      const canvas = await html2canvas(el, {
        scale: 2,
        backgroundColor: "#ffffff",
      });
      const img = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ unit: "pt", format: "letter" });
      const margin = 36; // 0.5in
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const usableW = pageW - margin * 2;
      const usableH = pageH - margin * 2;
      const ratio = canvas.height / canvas.width;
      let imgW = usableW;
      let imgH = usableW * ratio;
      if (imgH > usableH) {
        imgH = usableH;
        imgW = usableH / ratio;
      }
      pdf.addImage(img, "PNG", margin, margin, imgW, imgH);
      pdf.save(`Quote-${data.id}.pdf`);
      window.location.href = emailHref(data);
    } catch {
      toast({
        variant: "destructive",
        title: "Could not generate the quote PDF",
        description: "Please try again, or use Print to save it as a PDF.",
      });
    }
  };

  return (
    <div className="space-y-6">
      {data && (
        <div className="no-print flex justify-end gap-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button variant="outline" onClick={handleEmail}>
            <Mail className="h-4 w-4 mr-2" />
            Email
          </Button>
        </div>
      )}

      <div className="no-print">
        <CrudDetail
          singular="Quote"
          backPath="/quotes"
          titleKeys={["name", "customerName"]}
          row={data}
          isLoading={isLoading}
          fields={fields}
          extraDisplay={[
            { label: "Quote #", value: data ? `#${data.id}` : "—" },
            { label: "Total", value: formatCurrency(data?.total) },
            { label: "Customer", value: displayText(data?.customerName) },
          ]}
          onUpdate={(rid, d) => update.mutateAsync({ id: rid, data: d })}
          onDelete={(rid) => del.mutateAsync({ id: rid })}
          isMutating={update.isPending}
        />
      </div>

      {data && <QuotePrintView quote={data} />}

      {/* Off-screen full-width render used to rasterize the quote into a PDF
          for the Email action (html2canvas can't capture display:none nodes). */}
      {data && (
        <div
          aria-hidden
          className="text-black bg-white p-8"
          style={{ position: "fixed", left: "-9999px", top: 0, width: "816px" }}
        >
          <div ref={pdfRef}>
            <QuoteDocument quote={data} />
          </div>
        </div>
      )}
    </div>
  );
}

function QuotePrintView({ quote }: { quote: Quote }) {
  return (
    <div className="print-only hidden text-black">
      <QuoteDocument quote={quote} />
    </div>
  );
}

function QuoteDocument({ quote: q }: { quote: Quote }) {
  const cityStateZip = [
    [q.city, q.state].filter(Boolean).join(", "),
    q.zip,
  ]
    .filter(Boolean)
    .join(" ");

  const labeled = (label: string, value: ReactNode) => (
    <div className="flex gap-2">
      <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">
        {label}
      </span>
      <span className="flex-1 min-w-0 text-sm leading-5 h-5 block overflow-hidden whitespace-nowrap">
        {value || "\u00A0"}
      </span>
    </div>
  );

  return (
    <div className="text-black">
      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div className="w-1/3">
          <img src={Logo} alt="Eggen Weed Control" className="w-48 mb-2" />
        </div>
        <div className="text-center w-1/3 text-sm print-text-sm leading-tight">
          <div className="font-bold text-lg mb-1">EGGEN WEED CONTROL</div>
          <div>7619 E. Greenway Rd., Ste. 800</div>
          <div>Scottsdale, Arizona 85260-1712</div>
          <div className="mt-1">
            <span className="font-semibold">Phone:</span> (602) 996-1000
          </div>
          <div>
            <span className="font-semibold">Fax:</span> (602) 996-1813
          </div>
        </div>
        <div className="w-1/3 flex flex-col items-end">
          <div className="text-xl font-bold uppercase tracking-wider mb-2 text-black">
            QUOTATION
          </div>
          <div className="flex border print-border border-black">
            <div className="px-3 py-1 font-bold text-sm uppercase print-border-r border-r border-black">
              No.
            </div>
            <div className="px-3 py-1 font-mono">{q.id}</div>
          </div>
        </div>
      </div>

      {/* Row 1: Bill To & Quote Info */}
      <div className="flex gap-4">
        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black px-2 py-0.5">
            Bill To
          </div>
          <div className="p-2 space-y-1 text-sm">
            {labeled("Name", q.customerName)}
            {labeled("Property", q.propertyName)}
            {labeled("Address", q.address)}
            {labeled("City", cityStateZip)}
            {labeled("Phone", q.phoneNumber)}
            {labeled("Email", q.email)}
          </div>
        </div>

        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black px-2 py-0.5">
            Quote Information
          </div>
          <div className="p-2 space-y-1 text-sm">
            {labeled("Estimate", formatDate(q.estimateDate))}
            {labeled("Treat", formatDate(q.treatDate))}
            {labeled("Status", q.status)}
            {labeled("Sales", q.salesPerson)}
            {labeled("PO #", q.poNumber)}
          </div>
        </div>
      </div>

      {/* Job description */}
      {q.jobDescription && (
        <div className="mt-4 border print-border border-black">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black px-2 py-0.5">
            Job Description
          </div>
          <div className="p-2 text-sm whitespace-pre-wrap min-h-16">
            {q.jobDescription}
          </div>
        </div>
      )}

      {/* Total row */}
      <div className="flex gap-2 h-8 mt-4">
        <div className="flex-1 flex border print-border border-black items-center">
          <div className="text-[10px] font-bold uppercase border-r print-border-r border-black px-2 h-full flex items-center w-24">
            Total $
          </div>
          <div className="w-full h-full px-2 text-sm font-bold flex items-center">
            {formatCurrency(q.total)}
          </div>
        </div>
      </div>

      {/* Signature block */}
      <div className="flex gap-4 mt-10">
        <div className="flex-1">
          <div className="border-b border-black h-6" />
          <div className="text-[10px] uppercase font-semibold mt-1">
            Print Name
          </div>
        </div>
        <div className="flex-1">
          <div className="border-b border-black h-6" />
          <div className="text-[10px] uppercase font-semibold mt-1">
            Signature
          </div>
        </div>
        <div className="w-32">
          <div className="border-b border-black h-6" />
          <div className="text-[10px] uppercase font-semibold mt-1">Date</div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-center text-sm">
        <div className="font-bold italic">
          Thank you for the opportunity to serve you.
        </div>
      </div>
    </div>
  );
}
