import { useQueryClient } from "@tanstack/react-query";
import {
  useListProperties,
  useCreateProperty,
  useUpdateProperty,
  useDeleteProperty,
  useGetProperty,
  useListCustomers,
  getListPropertiesQueryKey,
  getGetPropertyQueryKey,
  type Property,
} from "@workspace/api-client-react";
import {
  CrudList,
  CrudDetail,
  StatusBadge,
  type FieldSpec,
  type Column,
} from "@/components/crud";
import { displayText } from "@/lib/format";

function useFields(): FieldSpec[] {
  const { data: customers } = useListCustomers();
  return [
    {
      name: "customerId",
      label: "Customer",
      type: "relation",
      nameField: "customerName",
      options: (customers ?? []).map((c) => ({
        value: String(c.id),
        label: c.customerName ?? `#${c.id}`,
      })),
      onSelect: (id) => {
        const c = (customers ?? []).find((x) => x.id === id);
        if (!c) return undefined;
        const extra: Record<string, unknown> = {};
        if (c.address) extra.streetAddress = c.address;
        if (c.city) extra.city = c.city;
        if (c.state) extra.state = c.state;
        if (c.zip) extra.zip = c.zip;
        if (c.contactNumber) extra.phone = c.contactNumber;
        if (c.contactName) extra.contact = c.contactName;
        return extra;
      },
    },
    { name: "name", label: "Property Name" },
    { name: "streetAddress", label: "Street Address", full: true },
    { name: "unit", label: "Unit" },
    { name: "city", label: "City" },
    { name: "state", label: "State", defaultValue: "AZ" },
    { name: "zip", label: "ZIP" },
    { name: "phone", label: "Phone" },
    { name: "contact", label: "Contact" },
    { name: "salesPerson", label: "Sales Person" },
    { name: "acreage", label: "Acreage", type: "number" },
    { name: "ratio", label: "Ratio", type: "number" },
    { name: "field", label: "Field" },
    { name: "grid", label: "Grid" },
    { name: "estimateDate", label: "Estimate Date", type: "date" },
    { name: "firstServiceDate", label: "First Service Date", type: "date" },
    { name: "nextServiceDate", label: "Next Service Date", type: "date" },
    { name: "time", label: "Time" },
    { name: "confirm", label: "Confirm" },
    { name: "jobDescription", label: "Job Description", type: "textarea" },
    { name: "quoteDescription", label: "Quote Description", type: "textarea" },
    { name: "specialInstructions", label: "Special Instructions", type: "textarea" },
    { name: "travelInstructions", label: "Travel Instructions", type: "textarea" },
  ];
}

const statusMap: Record<string, string> = {
  active: "bg-primary/15 text-primary",
  pending: "bg-secondary/20 text-secondary",
  inactive: "bg-muted text-muted-foreground",
};

const columns: Column<Property>[] = [
  { key: "id", header: "Property #", render: (r) => `#${r.id}` },
  { key: "name", header: "Property" },
  { key: "customerName", header: "Customer", filterable: true },
  { key: "city", header: "City", filterable: true },
  {
    key: "status",
    header: "Status",
    render: (r) => <StatusBadge value={r.status} map={statusMap} />,
    filterable: true,
  },
  { key: "nextServiceDate", header: "Next Service" },
];

function useMutations() {
  const qc = useQueryClient();
  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListPropertiesQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetPropertyQueryKey(id) });
  };
  const create = useCreateProperty({ mutation: { onSuccess: () => invalidate() } });
  const update = useUpdateProperty({
    mutation: { onSuccess: (d) => invalidate(d.id) },
  });
  const del = useDeleteProperty({ mutation: { onSuccess: () => invalidate() } });
  return { create, update, del };
}

export function Properties() {
  const { data, isLoading } = useListProperties();
  const fields = useFields();
  const { create, update, del } = useMutations();

  return (
    <CrudList
      title="Properties"
      singular="Property"
      rows={data ?? []}
      isLoading={isLoading}
      columns={columns}
      fields={fields}
      searchKeys={["name", "customerName", "city", "streetAddress", "contact"]}
      detailPath="/properties"
      onCreate={(d) => create.mutateAsync({ data: d })}
      onUpdate={(id, d) => update.mutateAsync({ id, data: d })}
      onDelete={(id) => del.mutateAsync({ id })}
      isMutating={create.isPending || update.isPending}
    />
  );
}

function mapsUrl(p?: Property): string | null {
  if (!p) return null;
  const parts = [p.streetAddress, p.unit, p.city, p.state, p.zip]
    .map((s) => (s ?? "").trim())
    .filter(Boolean);
  if (parts.length === 0) return null;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    parts.join(", "),
  )}`;
}

export function PropertyDetail({ id }: { id: number }) {
  const { data, isLoading } = useGetProperty(id, {
    query: { enabled: !!id, queryKey: getGetPropertyQueryKey(id) },
  });
  const fields = useFields();
  const { update, del } = useMutations();
  const url = mapsUrl(data);

  return (
    <CrudDetail
      singular="Property"
      backPath="/properties"
      titleKeys={["name", "streetAddress"]}
      row={data}
      isLoading={isLoading}
      fields={fields}
      extraDisplay={[
        { label: "Property #", value: data ? `#${data.id}` : "—" },
        { label: "Customer", value: displayText(data?.customerName) },
        {
          label: "Map",
          value: url ? (
            <a
              href={url}
              target="_blank"
              rel="noreferrer"
              className="text-primary underline underline-offset-2 hover:no-underline"
            >
              View on Google Maps
            </a>
          ) : (
            displayText(null)
          ),
        },
      ]}
      onUpdate={(rid, d) => update.mutateAsync({ id: rid, data: d })}
      onDelete={(rid) => del.mutateAsync({ id: rid })}
      isMutating={update.isPending}
    />
  );
}
