import { useQueryClient } from "@tanstack/react-query";
import {
  useListJobs,
  useCreateJob,
  useUpdateJob,
  useDeleteJob,
  useGetJob,
  useListProperties,
  getListJobsQueryKey,
  getGetJobQueryKey,
  type Job,
} from "@workspace/api-client-react";
import {
  CrudList,
  CrudDetail,
  StatusBadge,
  type FieldSpec,
  type Column,
} from "@/components/crud";

function useFields(): FieldSpec[] {
  const { data: properties } = useListProperties();
  return [
    {
      name: "propertyId",
      label: "Property",
      type: "relation",
      options: (properties ?? []).map((p) => ({
        value: String(p.id),
        label: p.name ?? `#${p.id}`,
      })),
      onSelect: (id) => {
        const p = (properties ?? []).find((x) => x.id === id);
        if (!p) return undefined;
        return {
          address: p.streetAddress ?? null,
          city: p.city ?? null,
          unit: p.unit ?? null,
          contact: p.contact ?? null,
        };
      },
    },
    { name: "name", label: "Job Name" },
    {
      name: "jobStatus",
      label: "Status",
      type: "select",
      options: JOB_STATUS_OPTIONS,
      defaultValue: "Open",
    },
    { name: "treatDate", label: "Treat Date", type: "date" },
    { name: "address", label: "Address", full: true },
    { name: "unit", label: "Unit" },
    { name: "city", label: "City" },
    { name: "contact", label: "Contact" },
    { name: "acreage", label: "Acreage", type: "number" },
    { name: "techName1", label: "Technician 1" },
    { name: "techName2", label: "Technician 2" },
    { name: "chemicals", label: "Chemicals" },
    { name: "gallons", label: "Gallons" },
    { name: "time", label: "Time" },
    { name: "arrivalTime", label: "Arrival Time" },
    { name: "additionalTime", label: "Additional Time" },
    { name: "tenEight", label: "10-8" },
    { name: "tenSeven", label: "10-7" },
    { name: "confirm", label: "Confirm" },
    { name: "jobDescription", label: "Job Description", type: "textarea" },
    { name: "scheduleInstructions", label: "Schedule Instructions", type: "textarea" },
    { name: "specialInstructions", label: "Special Instructions", type: "textarea" },
    { name: "travelInstructions", label: "Travel Instructions", type: "textarea" },
    { name: "notes", label: "Notes", type: "textarea" },
  ];
}

const JOB_STATUS_OPTIONS = [
  { value: "Open", label: "Open" },
  { value: "Scheduled", label: "Scheduled" },
  { value: "Complete", label: "Complete" },
  { value: "Invoiced", label: "Invoiced" },
];

const statusMap: Record<string, string> = {
  open: "bg-destructive/15 text-destructive",
  scheduled: "bg-secondary/20 text-secondary",
  complete: "bg-primary/15 text-primary",
  invoiced: "bg-muted text-muted-foreground",
};

const columns: Column<Job>[] = [
  { key: "id", header: "Job #", render: (r) => `#${r.id}` },
  { key: "name", header: "Job" },
  {
    key: "quoteId",
    header: "Quote #",
    render: (r) => (r.quoteId != null ? `#${r.quoteId}` : "—"),
  },
  { key: "address", header: "Address" },
  { key: "city", header: "City", filterable: true },
  {
    key: "treatDate",
    header: "Treat Date",
    filterable: true,
    filterType: "dateRange",
  },
  {
    key: "jobStatus",
    header: "Status",
    render: (r) => <StatusBadge value={r.jobStatus} map={statusMap} />,
    filterable: true,
  },
];

function useMutations() {
  const qc = useQueryClient();
  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetJobQueryKey(id) });
  };
  const create = useCreateJob({ mutation: { onSuccess: () => invalidate() } });
  const update = useUpdateJob({ mutation: { onSuccess: (d) => invalidate(d.id) } });
  const del = useDeleteJob({ mutation: { onSuccess: () => invalidate() } });
  return { create, update, del };
}

export function Jobs() {
  const { data, isLoading } = useListJobs();
  const fields = useFields();
  const { create, update, del } = useMutations();

  return (
    <CrudList
      title="Jobs"
      singular="Job"
      rows={data ?? []}
      isLoading={isLoading}
      columns={columns}
      fields={fields}
      searchKeys={["name", "address", "city", "contact", "techName1"]}
      detailPath="/jobs"
      onCreate={(d) => create.mutateAsync({ data: d })}
      onUpdate={(id, d) => update.mutateAsync({ id, data: d })}
      onDelete={(id) => del.mutateAsync({ id })}
      isMutating={create.isPending || update.isPending}
    />
  );
}

export function JobDetail({ id }: { id: number }) {
  const { data, isLoading } = useGetJob(id, {
    query: { enabled: !!id, queryKey: getGetJobQueryKey(id) },
  });
  const fields = useFields();
  const { update, del } = useMutations();

  return (
    <CrudDetail
      singular="Job"
      backPath="/jobs"
      titleKeys={["name", "address"]}
      row={data}
      isLoading={isLoading}
      fields={fields}
      extraDisplay={[
        { label: "Job #", value: data ? `#${data.id}` : "—" },
        {
          label: "Quote #",
          value: data?.quoteId != null ? `#${data.quoteId}` : "—",
        },
        {
          label: "Status",
          value: <StatusBadge value={data?.jobStatus} map={statusMap} />,
        },
      ]}
      onUpdate={(rid, d) => update.mutateAsync({ id: rid, data: d })}
      onDelete={(rid) => del.mutateAsync({ id: rid })}
      isMutating={update.isPending}
    />
  );
}
