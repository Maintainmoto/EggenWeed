import { useRef, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas-pro";
import {
  useListInvoices,
  useCreateInvoice,
  useUpdateInvoice,
  useDeleteInvoice,
  useGetInvoice,
  useListJobs,
  useListQuotes,
  getListInvoicesQueryKey,
  getGetInvoiceQueryKey,
  getListJobsQueryKey,
  type Invoice,
} from "@workspace/api-client-react";
import {
  CrudList,
  CrudDetail,
  StatusBadge,
  paymentStatusMap,
  type FieldSpec,
  type Column,
} from "@/components/crud";
import { Printer, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/format";
import Logo from "@assets/Logo_1781823781016.png";

const PAYMENT_STATUS_OPTIONS = [
  { value: "Not Sent", label: "Not Sent" },
  { value: "Sent", label: "Sent" },
  { value: "Partially Paid", label: "Partially Paid" },
  { value: "Paid", label: "Paid" },
];

function useFields(): FieldSpec[] {
  const { data: jobs } = useListJobs();
  const { data: quotes } = useListQuotes();
  return [
    {
      name: "jobId",
      label: "Job",
      type: "relation",
      options: (jobs ?? []).map((j) => ({
        value: String(j.id),
        label: j.name ?? `#${j.id}`,
      })),
    },
    {
      name: "quoteId",
      label: "Quote",
      type: "relation",
      options: (quotes ?? []).map((q) => ({
        value: String(q.id),
        label: `#${q.id}${q.name ? ` — ${q.name}` : ""}`,
      })),
      onSelect: (id) => {
        const q = (quotes ?? []).find((x) => x.id === id);
        if (!q) return undefined;
        return {
          customerName: q.customerName ?? null,
          address: q.address ?? null,
          city: q.city ?? null,
          state: q.state ?? null,
          zip: q.zip ?? null,
          phone: q.phoneNumber ?? null,
          email: q.email ?? null,
        };
      },
    },
    { name: "customerName", label: "Customer Name", full: true },
    { name: "address", label: "Address", full: true },
    { name: "city", label: "City" },
    { name: "state", label: "State", defaultValue: "AZ" },
    { name: "zip", label: "ZIP" },
    { name: "phone", label: "Phone" },
    { name: "email", label: "Email" },
    {
      name: "paymentStatus",
      label: "Payment Status",
      type: "select",
      options: PAYMENT_STATUS_OPTIONS,
    },
    { name: "total", label: "Total", type: "number", currency: true },
    { name: "amountPaid", label: "Amount Paid", type: "number", currency: true },
    { name: "checkNumber", label: "Check Number" },
    { name: "invoiceDate", label: "Invoice Date", type: "date" },
    { name: "datePaid", label: "Date Paid", type: "date" },
  ];
}

const columns: Column<Invoice>[] = [
  { key: "id", header: "Invoice #" },
  { key: "customerName", header: "Customer", filterable: true },
  { key: "total", header: "Total", render: (r) => formatCurrency(r.total) },
  {
    key: "balanceDue",
    header: "Balance Due",
    render: (r) => formatCurrency(r.balanceDue),
  },
  {
    key: "paymentStatus",
    header: "Status",
    render: (r) => (
      <StatusBadge value={r.paymentStatus} map={paymentStatusMap} />
    ),
    filterable: true,
  },
];

function useMutations() {
  const qc = useQueryClient();
  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
    qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetInvoiceQueryKey(id) });
  };
  const create = useCreateInvoice({ mutation: { onSuccess: () => invalidate() } });
  const update = useUpdateInvoice({
    mutation: { onSuccess: (d) => invalidate(d.id) },
  });
  const del = useDeleteInvoice({ mutation: { onSuccess: () => invalidate() } });
  return { create, update, del };
}

export function Invoices() {
  const { data, isLoading } = useListInvoices();
  const fields = useFields();
  const { create, update, del } = useMutations();

  return (
    <CrudList
      title="Invoices"
      singular="Invoice"
      rows={data ?? []}
      isLoading={isLoading}
      columns={columns}
      fields={fields}
      searchKeys={["customerName", "checkNumber", "paymentStatus"]}
      detailPath="/invoices"
      onCreate={(d) => create.mutateAsync({ data: d })}
      onUpdate={(id, d) => update.mutateAsync({ id, data: d })}
      onDelete={(id) => del.mutateAsync({ id })}
      isMutating={create.isPending || update.isPending}
    />
  );
}

function emailHref(inv: Invoice): string {
  const ref = `Invoice #${inv.id}`;
  const lines = [
    `${ref}`,
    inv.customerName ? `Customer: ${inv.customerName}` : null,
    inv.invoiceDate ? `Invoice Date: ${formatDate(inv.invoiceDate)}` : null,
    inv.total != null ? `Total: ${formatCurrency(inv.total)}` : null,
    inv.amountPaid != null
      ? `Amount Paid: ${formatCurrency(inv.amountPaid)}`
      : null,
    inv.balanceDue != null
      ? `Balance Due: ${formatCurrency(inv.balanceDue)}`
      : null,
    "",
    "Please find your invoice attached as a PDF.",
    "",
    "Thank you,",
    "Eggen Weed Control",
  ].filter((l) => l != null);
  const params = new URLSearchParams({
    subject: `${ref} — Eggen Weed Control`,
    body: lines.join("\n"),
  });
  const to = inv.email ? encodeURIComponent(inv.email) : "";
  return `mailto:${to}?${params.toString()}`;
}

export function InvoiceDetail({ id }: { id: number }) {
  const { data, isLoading } = useGetInvoice(id, {
    query: { enabled: !!id, queryKey: getGetInvoiceQueryKey(id) },
  });
  const fields = useFields();
  const { update, del } = useMutations();
  const { toast } = useToast();
  const pdfRef = useRef<HTMLDivElement>(null);

  const handleEmail = async () => {
    const el = pdfRef.current;
    if (!el || !data) return;
    try {
      const canvas = await html2canvas(el, {
        scale: 2,
        backgroundColor: "#ffffff",
      });
      const img = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ unit: "pt", format: "letter" });
      const margin = 36; // 0.5in
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const usableW = pageW - margin * 2;
      const usableH = pageH - margin * 2;
      const ratio = canvas.height / canvas.width;
      let imgW = usableW;
      let imgH = usableW * ratio;
      if (imgH > usableH) {
        imgH = usableH;
        imgW = usableH / ratio;
      }
      pdf.addImage(img, "PNG", margin, margin, imgW, imgH);
      pdf.save(`Invoice-${data.id}.pdf`);
      window.location.href = emailHref(data);
    } catch {
      toast({
        variant: "destructive",
        title: "Could not generate the invoice PDF",
        description: "Please try again, or use Print to save it as a PDF.",
      });
    }
  };

  return (
    <div className="space-y-6">
      {data && (
        <div className="no-print flex justify-end gap-2">
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button variant="outline" onClick={handleEmail}>
            <Mail className="h-4 w-4 mr-2" />
            Email
          </Button>
        </div>
      )}

      <div className="no-print">
        <CrudDetail
          singular="Invoice"
          backPath="/invoices"
          titleKeys={["customerName"]}
          row={data}
          isLoading={isLoading}
          fields={fields}
          extraDisplay={[
            { label: "Invoice #", value: data ? `#${data.id}` : "—" },
            {
              label: "Payment Status",
              value: (
                <StatusBadge
                  value={data?.paymentStatus}
                  map={paymentStatusMap}
                />
              ),
            },
            { label: "Balance Due", value: formatCurrency(data?.balanceDue) },
          ]}
          onUpdate={(rid, d) => update.mutateAsync({ id: rid, data: d })}
          onDelete={(rid) => del.mutateAsync({ id: rid })}
          isMutating={update.isPending}
        />
      </div>

      {data && <InvoicePrintView invoice={data} />}

      {/* Off-screen full-width render used to rasterize the invoice into a PDF
          for the Email action (html2canvas can't capture display:none nodes). */}
      {data && (
        <div
          aria-hidden
          className="text-black bg-white p-8"
          style={{ position: "fixed", left: "-9999px", top: 0, width: "816px" }}
        >
          <div ref={pdfRef}>
            <InvoiceDocument invoice={data} />
          </div>
        </div>
      )}
    </div>
  );
}

function InvoicePrintView({ invoice }: { invoice: Invoice }) {
  return (
    <div className="print-only hidden text-black">
      <InvoiceDocument invoice={invoice} />
    </div>
  );
}

function InvoiceDocument({ invoice: inv }: { invoice: Invoice }) {
  const cityStateZip = [
    [inv.city, inv.state].filter(Boolean).join(", "),
    inv.zip,
  ]
    .filter(Boolean)
    .join(" ");

  const labeled = (label: string, value: ReactNode) => (
    <div className="flex gap-2">
      <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">
        {label}
      </span>
      <span className="flex-1 min-w-0 text-sm leading-5 h-5 block overflow-hidden whitespace-nowrap">
        {value || "\u00A0"}
      </span>
    </div>
  );

  return (
    <div className="text-black">
      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div className="w-1/3">
          <img src={Logo} alt="Eggen Weed Control" className="w-48 mb-2" />
        </div>
        <div className="text-center w-1/3 text-sm print-text-sm leading-tight">
          <div className="font-bold text-lg mb-1">EGGEN WEED CONTROL</div>
          <div>7619 E. Greenway Rd., Ste. 800</div>
          <div>Scottsdale, Arizona 85260-1712</div>
          <div className="mt-1">
            <span className="font-semibold">Phone:</span> (602) 996-1000
          </div>
          <div>
            <span className="font-semibold">Fax:</span> (602) 996-1813
          </div>
        </div>
        <div className="w-1/3 flex flex-col items-end">
          <div className="text-xl font-bold uppercase tracking-wider mb-2 text-black">
            INVOICE
          </div>
          <div className="flex border print-border border-black">
            <div className="px-3 py-1 font-bold text-sm uppercase print-border-r border-r border-black">
              No.
            </div>
            <div className="px-3 py-1 font-mono">{inv.id}</div>
          </div>
        </div>
      </div>

      {/* Row 1: Bill To & Invoice Info */}
      <div className="flex gap-4">
        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black px-2 py-0.5">
            Bill To
          </div>
          <div className="p-2 space-y-1 text-sm">
            {labeled("Name", inv.customerName)}
            {labeled("Address", inv.address)}
            {labeled("City", cityStateZip)}
            {labeled("Phone", inv.phone)}
            {labeled("Email", inv.email)}
          </div>
        </div>

        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black px-2 py-0.5">
            Invoice Information
          </div>
          <div className="p-2 space-y-1 text-sm">
            {labeled("Date", formatDate(inv.invoiceDate))}
            {labeled("Check #", inv.checkNumber)}
            {labeled("Status", inv.paymentStatus)}
          </div>
        </div>
      </div>

      {/* Totals row */}
      <div className="flex gap-2 h-8 mt-4">
        <div className="flex-1 flex border print-border border-black items-center">
          <div className="text-[10px] font-bold uppercase border-r print-border-r border-black px-2 h-full flex items-center w-24">
            Total $
          </div>
          <div className="w-full h-full px-2 text-sm font-bold flex items-center">
            {formatCurrency(inv.total)}
          </div>
        </div>
        <div className="flex-1 flex border print-border border-black items-center">
          <div className="text-[10px] font-bold uppercase border-r print-border-r border-black px-2 h-full flex items-center w-24">
            Amount Paid $
          </div>
          <div className="w-full h-full px-2 text-sm flex items-center">
            {formatCurrency(inv.amountPaid)}
          </div>
        </div>
        <div className="flex-1 flex border print-border border-black items-center">
          <div className="text-[10px] font-bold uppercase border-r print-border-r border-black px-2 h-full flex items-center w-24">
            Balance Due $
          </div>
          <div className="w-full h-full px-2 text-sm font-bold flex items-center">
            {formatCurrency(inv.balanceDue)}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-8 text-center text-sm">
        <div className="font-bold italic">Payable upon receipt — Thank you.</div>
      </div>
    </div>
  );
}
