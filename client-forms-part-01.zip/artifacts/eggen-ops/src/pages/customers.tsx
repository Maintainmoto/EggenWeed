import { useQueryClient } from "@tanstack/react-query";
import {
  useListCustomers,
  useCreateCustomer,
  useUpdateCustomer,
  useDeleteCustomer,
  useGetCustomer,
  getListCustomersQueryKey,
  getGetCustomerQueryKey,
  type Customer,
} from "@workspace/api-client-react";
import {
  CrudList,
  CrudDetail,
  type FieldSpec,
  type Column,
} from "@/components/crud";
import { displayText } from "@/lib/format";

const fields: FieldSpec[] = [
  { name: "customerName", label: "Customer Name", full: true },
  {
    name: "customerType",
    label: "Type",
    type: "select",
    options: [
      { value: "Commercial", label: "Commercial" },
      { value: "Residential", label: "Residential" },
    ],
  },
  { name: "contactName", label: "Contact Name" },
  { name: "contactNumber", label: "Contact Number" },
  { name: "email", label: "Email" },
  { name: "address", label: "Address", full: true },
  { name: "city", label: "City" },
  { name: "state", label: "State", defaultValue: "AZ" },
  { name: "zip", label: "ZIP" },
];

const columns: Column<Customer>[] = [
  { key: "id", header: "Customer #", render: (r) => `#${r.id}`, sortable: true },
  { key: "customerName", header: "Name", sortable: true },
  { key: "customerType", header: "Type", filterable: true, sortable: true },
  { key: "contactName", header: "Contact" },
  { key: "contactNumber", header: "Phone" },
  { key: "city", header: "City", filterable: true },
];

function useCustomerMutations() {
  const qc = useQueryClient();
  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListCustomersQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetCustomerQueryKey(id) });
  };
  const create = useCreateCustomer({
    mutation: { onSuccess: () => invalidate() },
  });
  const update = useUpdateCustomer({
    mutation: { onSuccess: (d) => invalidate(d.id) },
  });
  const del = useDeleteCustomer({ mutation: { onSuccess: () => invalidate() } });
  return { create, update, del };
}

export function Customers() {
  const { data, isLoading } = useListCustomers();
  const { create, update, del } = useCustomerMutations();

  return (
    <CrudList
      title="Customers"
      singular="Customer"
      rows={data ?? []}
      isLoading={isLoading}
      columns={columns}
      fields={fields}
      searchKeys={["id", "customerName", "contactName", "city", "contactNumber"]}
      detailPath="/customers"
      onCreate={(d) => create.mutateAsync({ data: d })}
      onUpdate={(id, d) => update.mutateAsync({ id, data: d })}
      onDelete={(id) => del.mutateAsync({ id })}
      isMutating={create.isPending || update.isPending}
    />
  );
}

export function CustomerDetail({ id }: { id: number }) {
  const { data, isLoading } = useGetCustomer(id, {
    query: { enabled: !!id, queryKey: getGetCustomerQueryKey(id) },
  });
  const { update, del } = useCustomerMutations();

  return (
    <CrudDetail
      singular="Customer"
      backPath="/customers"
      titleKeys={["customerName"]}
      row={data}
      isLoading={isLoading}
      fields={fields}
      extraDisplay={[
        { label: "Customer #", value: data ? `#${data.id}` : "—" },
        { label: "Customer Type", value: displayText(data?.customerType) },
      ]}
      onUpdate={(rid, d) => update.mutateAsync({ id: rid, data: d })}
      onDelete={(rid) => del.mutateAsync({ id: rid })}
      isMutating={update.isPending}
    />
  );
}
