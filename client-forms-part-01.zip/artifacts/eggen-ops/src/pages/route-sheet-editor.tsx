import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  Printer,
  Save,
  Trash2,
  ArrowLeft,
  Loader2,
  Plus,
  ChevronUp,
  ChevronDown,
  X,
  CheckCircle2,
} from "lucide-react";
import {
  useGetRouteSheet,
  useCreateRouteSheet,
  useUpdateRouteSheet,
  useDeleteRouteSheet,
  useCompleteRouteSheet,
  useListProperties,
  useListJobs,
  getListRouteSheetsQueryKey,
  getGetRouteSheetQueryKey,
  getListJobsQueryKey,
  type RouteSheetStopInput,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const SERVICE_TYPES = ["SPOT", "FULL", "PRE", "POST", "RENEW", "INSPECT"];

interface StopRow extends RouteSheetStopInput {
  _key: string;
}

interface HeaderState {
  date: string;
  unit: string;
  sprayer: string;
  sprayer2: string;
  typeOfRoute: string;
  rigHours: string;
  notes: string;
}

const emptyHeader: HeaderState = {
  date: "",
  unit: "",
  sprayer: "",
  sprayer2: "",
  typeOfRoute: "",
  rigHours: "",
  notes: "",
};

let keyCounter = 0;
const nextKey = () => `row-${keyCounter++}`;

function dayOfWeek(value: string) {
  if (!value) return "";
  const d = new Date(value + "T00:00:00");
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-US", { weekday: "long" });
}

function jobName(s: StopRow) {
  const parts = [s.serviceType, s.propertyName, s.address].filter(Boolean);
  return parts.join(" - ");
}

export function RouteSheetEditor() {
  const params = useParams<{ id?: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const qc = useQueryClient();

  const isNew = !params.id || params.id === "new";
  const sheetId = isNew ? null : parseInt(params.id!, 10);

  const [header, setHeader] = useState<HeaderState>(emptyHeader);
  const [stops, setStops] = useState<StopRow[]>([]);
  const [addJobId, setAddJobId] = useState<string>("");
  // Tracks local edits (header/stops) not yet persisted to the server. Adding a
  // job only changes local state, so this flags that a Save is still needed —
  // important because "Mark Route Complete" acts on the server's saved stops.
  const [dirty, setDirty] = useState(false);

  const { data: properties } = useListProperties();
  const { data: jobs } = useListJobs();
  const { data: sheet, isLoading } = useGetRouteSheet(sheetId as number, {
    query: { enabled: !!sheetId, queryKey: getGetRouteSheetQueryKey(sheetId as number) },
  });

  useEffect(() => {
    if (sheet) {
      setHeader({
        date: sheet.date ?? "",
        unit: sheet.unit ?? "",
        sprayer: sheet.sprayer ?? "",
        sprayer2: sheet.sprayer2 ?? "",
        typeOfRoute: sheet.typeOfRoute ?? "",
        rigHours: sheet.rigHours ?? "",
        notes: sheet.notes ?? "",
      });
      setStops(
        (sheet.stops ?? []).map((s) => ({
          _key: nextKey(),
          propertyId: s.propertyId ?? null,
          jobId: s.jobId ?? null,
          serviceType: s.serviceType ?? "SPOT",
          et: s.et ?? "",
          propertyName: s.propertyName ?? "",
          customerName: s.customerName ?? "",
          address: s.address ?? "",
          grid: s.grid ?? "",
          idNumber: s.idNumber ?? "",
          phone: s.phone ?? "",
        })),
      );
      setDirty(false);
    }
  }, [sheet]);

  const invalidate = (id?: number) => {
    qc.invalidateQueries({ queryKey: getListRouteSheetsQueryKey() });
    qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
    if (id) qc.invalidateQueries({ queryKey: getGetRouteSheetQueryKey(id) });
  };

  const create = useCreateRouteSheet({
    mutation: {
      onSuccess: (data) => {
        invalidate(data.id);
        setDirty(false);
        toast({ title: "Route sheet saved" });
        setLocation(`/route-sheets/${data.id}`);
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Could not save route sheet",
          description: "Please try again.",
        });
      },
    },
  });
  const update = useUpdateRouteSheet({
    mutation: {
      onSuccess: (data) => {
        invalidate(data.id);
        setDirty(false);
        toast({ title: "Route sheet saved" });
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Could not save route sheet",
          description: "Please try again.",
        });
      },
    },
  });
  const del = useDeleteRouteSheet({
    mutation: {
      onSuccess: () => {
        invalidate();
        toast({ title: "Route sheet deleted" });
        setLocation("/route-sheets");
      },
    },
  });
  const complete = useCompleteRouteSheet({
    mutation: {
      onSuccess: (data) => {
        invalidate(data.id);
        toast({
          title: "Route marked complete",
          description: "Linked jobs are now ready to invoice.",
        });
      },
      onError: () => {
        toast({
          variant: "destructive",
          title: "Could not mark route complete",
          description: "Please try again.",
        });
      },
    },
  });

  function setHeaderField(key: keyof HeaderState, value: string) {
    setHeader((h) => ({ ...h, [key]: value }));
    setDirty(true);
  }

  function addStop() {
    if (!addJobId) return;
    const job = (jobs ?? []).find((j) => String(j.id) === addJobId);
    if (!job) return;
    const prop = (properties ?? []).find((p) => p.id === job.propertyId);
    setStops((rows) => [
      ...rows,
      {
        _key: nextKey(),
        jobId: job.id,
        propertyId: job.propertyId ?? prop?.id ?? null,
        serviceType: "SPOT",
        et: "",
        propertyName: prop?.name ?? job.name ?? "",
        customerName: prop?.customerName ?? "",
        address: prop?.streetAddress ?? job.address ?? "",
        grid: prop?.grid ?? "",
        idNumber: "",
        phone: prop?.phone ?? "",
      },
    ]);
    setAddJobId("");
    setDirty(true);
  }

  function updateStop(key: string, patch: Partial<StopRow>) {
    setStops((rows) =>
      rows.map((r) => (r._key === key ? { ...r, ...patch } : r)),
    );
    setDirty(true);
  }

  function removeStop(key: string) {
    setStops((rows) => rows.filter((r) => r._key !== key));
    setDirty(true);
  }

  function moveStop(key: string, dir: -1 | 1) {
    setStops((rows) => {
      const idx = rows.findIndex((r) => r._key === key);
      if (idx < 0) return rows;
      const target = idx + dir;
      if (target < 0 || target >= rows.length) return rows;
      const copy = [...rows];
      [copy[idx], copy[target]] = [copy[target], copy[idx]];
      return copy;
    });
    setDirty(true);
  }

  function buildPayload() {
    const clean = (v: string) => {
      const t = v.trim();
      return t === "" ? null : t;
    };
    return {
      date: clean(header.date),
      unit: clean(header.unit),
      sprayer: clean(header.sprayer),
      sprayer2: clean(header.sprayer2),
      typeOfRoute: clean(header.typeOfRoute),
      rigHours: clean(header.rigHours),
      notes: clean(header.notes),
      stops: stops.map((s, i) => ({
        propertyId: s.propertyId ?? null,
        jobId: s.jobId ?? null,
        position: i,
        serviceType: s.serviceType ?? null,
        et: s.et ?? null,
        propertyName: s.propertyName ?? null,
        customerName: s.customerName ?? null,
        address: s.address ?? null,
        grid: s.grid ?? null,
        idNumber: s.idNumber ?? null,
        phone: s.phone ?? null,
      })),
    };
  }

  function handleSave() {
    const payload = buildPayload();
    if (isNew) {
      create.mutate({ data: payload });
    } else {
      update.mutate({ id: sheetId!, data: payload });
    }
  }

  function handleDelete() {
    if (sheetId && confirm("Delete this route sheet? This cannot be undone.")) {
      del.mutate({ id: sheetId });
    }
  }

  async function handleComplete() {
    if (!sheetId) return;
    if (
      !confirm(
        "Mark this route complete? Any unsaved changes will be saved first, then all jobs on this route are set to Complete (ready to invoice).",
      )
    ) {
      return;
    }
    try {
      // Persist the current stops first so jobs added but not yet saved are
      // included — the complete endpoint only acts on saved route stops. Skip
      // the save when there's nothing pending to avoid a redundant write.
      if (dirty) {
        await update.mutateAsync({ id: sheetId, data: buildPayload() });
      }
      await complete.mutateAsync({ id: sheetId });
    } catch {
      // onError handlers on the mutations surface the failure toast.
    }
  }

  const isSaving = create.isPending || update.isPending;

  if (!isNew && isLoading) {
    return (
      <div className="py-20 flex justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const propsById = new Map((properties ?? []).map((p) => [p.id, p]));
  const openJobOptions = (jobs ?? [])
    .filter((j) => {
      const s = (j.jobStatus ?? "").trim().toLowerCase();
      return s === "" || s === "open";
    })
    .map((j) => {
      const prop = j.propertyId != null ? propsById.get(j.propertyId) : undefined;
      const label =
        prop?.name ?? j.name ?? `Job #${j.id}`;
      const sub = prop?.streetAddress ?? j.address ?? "";
      return { id: j.id, label, sub };
    })
    .sort((a, b) => a.label.localeCompare(b.label));

  const routeNumber = sheet?.routeNumber ?? null;

  return (
    <div className="space-y-6">
      {/* Heading */}
      <div className="no-print">
        <h1 className="text-2xl font-semibold tracking-tight">
          {isNew
            ? "New Route Sheet"
            : routeNumber != null
              ? `Route #${routeNumber}`
              : "Route Sheet"}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {isNew
            ? "Fill in the details and save to assign a route number."
            : header.date
              ? `${dayOfWeek(header.date)} · ${header.date}`
              : "No date set"}
        </p>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between no-print">
        <Button variant="ghost" onClick={() => setLocation("/route-sheets")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div className="flex items-center gap-2">
          {!isNew && (
            <Button variant="outline" onClick={handleDelete}>
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </Button>
          )}
          {!isNew && (
            <Button
              variant="outline"
              onClick={handleComplete}
              disabled={complete.isPending || isSaving}
            >
              {complete.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <CheckCircle2 className="h-4 w-4 mr-2" />
              )}
              Mark Route Complete
            </Button>
          )}
          <Button variant="outline" onClick={() => window.print()}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          {dirty && (
            <span className="text-xs font-medium text-amber-600 self-center">
              Unsaved changes
            </span>
          )}
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Save
          </Button>
        </div>
      </div>

      {/* Editor form (screen only) */}
      <div className="no-print space-y-6">
        <Card>
          <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input
                type="date"
                value={header.date}
                onChange={(e) => setHeaderField("date", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Unit</Label>
              <Input
                value={header.unit}
                onChange={(e) => setHeaderField("unit", e.target.value)}
                placeholder="Unit #"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Type of Route</Label>
              <Input
                value={header.typeOfRoute}
                onChange={(e) => setHeaderField("typeOfRoute", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Sprayer</Label>
              <Input
                value={header.sprayer}
                onChange={(e) => setHeaderField("sprayer", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Sprayer 2</Label>
              <Input
                value={header.sprayer2}
                onChange={(e) => setHeaderField("sprayer2", e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Rig Hours</Label>
              <Input
                value={header.rigHours}
                onChange={(e) => setHeaderField("rigHours", e.target.value)}
              />
            </div>
            <div className="space-y-1.5 md:col-span-3">
              <Label>Notes</Label>
              <Input
                value={header.notes}
                onChange={(e) => setHeaderField("notes", e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Add stop */}
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div className="flex items-end gap-3">
              <div className="flex-1 space-y-1.5">
                <Label>Add Open Job</Label>
                <Select value={addJobId} onValueChange={setAddJobId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an open job…" />
                  </SelectTrigger>
                  <SelectContent>
                    {openJobOptions.length === 0 ? (
                      <div className="px-2 py-1.5 text-sm text-muted-foreground">
                        No open jobs
                      </div>
                    ) : (
                      openJobOptions.map((o) => (
                        <SelectItem key={o.id} value={String(o.id)}>
                          {o.label}
                          {o.sub ? ` — ${o.sub}` : ""}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={addStop} disabled={!addJobId}>
                <Plus className="h-4 w-4 mr-2" />
                Add
              </Button>
            </div>

            {stops.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">
                No stops yet. Add open jobs above to build the route.
              </p>
            ) : (
              <div className="space-y-3">
                {stops.map((s, i) => (
                  <div
                    key={s._key}
                    className="border rounded-md p-3 flex flex-col gap-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-sm">
                        {i + 1}. {s.propertyName || "Property"}
                        {s.customerName ? (
                          <span className="text-muted-foreground font-normal">
                            {" "}
                            · {s.customerName}
                          </span>
                        ) : null}
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => moveStop(s._key, -1)}
                          disabled={i === 0}
                        >
                          <ChevronUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => moveStop(s._key, 1)}
                          disabled={i === stops.length - 1}
                        >
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeStop(s._key)}
                        >
                          <X className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="space-y-1.5">
                        <Label className="text-xs">Service Type</Label>
                        <Select
                          value={s.serviceType ?? "SPOT"}
                          onValueChange={(v) =>
                            updateStop(s._key, { serviceType: v })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {SERVICE_TYPES.map((t) => (
                              <SelectItem key={t} value={t}>
                                {t}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">ET</Label>
                        <Input
                          value={s.et ?? ""}
                          onChange={(e) =>
                            updateStop(s._key, { et: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">ID# (Tech)</Label>
                        <Input
                          value={s.idNumber ?? ""}
                          onChange={(e) =>
                            updateStop(s._key, { idNumber: e.target.value })
                          }
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs">Grid</Label>
                        <Input
                          value={s.grid ?? ""}
                          onChange={(e) =>
                            updateStop(s._key, { grid: e.target.value })
                          }
                        />
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {jobName(s)}
                      {s.phone ? ` · ${s.phone}` : ""}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Bottom save bar */}
        <div className="flex items-center justify-end gap-3 pb-4">
          {dirty && (
            <span className="text-xs font-medium text-amber-600">
              Unsaved changes
            </span>
          )}
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isNew ? "Save Route" : "Save Changes"}
          </Button>
        </div>
      </div>

      {/* Print view */}
      <PrintSheet header={header} stops={stops} routeNumber={routeNumber} />
    </div>
  );
}

function PrintSheet({
  header,
  stops,
  routeNumber,
}: {
  header: HeaderState;
  stops: StopRow[];
  routeNumber: number | null;
}) {
  return (
    <div className="print-only hidden text-black">
      <div className="flex items-end justify-between mb-2">
        <div className="text-lg font-bold tracking-wide">DAILY ROUTE SHEET</div>
        <div className="text-right text-xs">
          <div>Eggen Weed Control</div>
          {routeNumber != null && (
            <div className="font-semibold">Route #{routeNumber}</div>
          )}
        </div>
      </div>

      {/* Header grid */}
      <div className="grid grid-cols-3 gap-x-6 gap-y-1 mb-3 print-text-sm">
        <div>
          <span className="font-semibold">Date: </span>
          {header.date || "________"}
        </div>
        <div>
          <span className="font-semibold">Day: </span>
          {dayOfWeek(header.date) || "________"}
        </div>
        <div>
          <span className="font-semibold">Unit: </span>
          {header.unit || "________"}
        </div>
        <div>
          <span className="font-semibold">Sprayer: </span>
          {header.sprayer || "________"}
        </div>
        <div>
          <span className="font-semibold">Sprayer: </span>
          {header.sprayer2 || "________"}
        </div>
        <div>
          <span className="font-semibold">Type of Route: </span>
          {header.typeOfRoute || "________"}
        </div>
        <div className="col-span-3">
          <span className="font-semibold">Rig Hours: </span>
          <span className="inline-block min-w-[120px] border-b border-black">
            &nbsp;
          </span>
        </div>
      </div>

      <table className="w-full border-collapse print-text-sm">
        <thead>
          <tr>
            <th className="print-border p-1 text-left w-6">#</th>
            <th className="print-border p-1 text-center w-16">
              Start
              <br />
              End
            </th>
            <th className="print-border p-1 text-center w-16">
              Mileage
              <br />
              Mileage
            </th>
            <th className="print-border p-1 text-center w-10">ET</th>
            <th className="print-border p-1 text-left">JOB NAME</th>
            <th className="print-border p-1 text-center w-12">Grid</th>
            <th className="print-border p-1 text-center w-16">ID#</th>
            <th className="print-border p-1 text-center w-24">
              Hm. Tel
              <br />
              Bus. Tel
            </th>
          </tr>
        </thead>
        <tbody>
          {stops.map((s, i) => (
            <tr key={s._key}>
              <td className="print-border p-1 text-left align-top">{i + 1}</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 text-center align-top">
                {s.et || ""}
              </td>
              <td className="print-border p-1 align-top">{jobName(s)}</td>
              <td className="print-border p-1 text-center align-top">
                {s.grid || ""}
              </td>
              <td className="print-border p-1 text-center align-top">
                {s.idNumber || ""}
              </td>
              <td className="print-border p-1 text-center align-top">
                {s.phone || ""}
              </td>
            </tr>
          ))}
          {Array.from({ length: Math.max(0, 18 - stops.length) }).map((_, i) => (
            <tr key={`blank-${i}`}>
              <td className="print-border p-1 align-top">
                {stops.length + i + 1}
              </td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
              <td className="print-border p-1 align-top">&nbsp;</td>
            </tr>
          ))}
        </tbody>
      </table>

      {header.notes ? (
        <div className="mt-3 print-text-sm">
          <span className="font-semibold">Notes: </span>
          {header.notes}
        </div>
      ) : null}
    </div>
  );
}
