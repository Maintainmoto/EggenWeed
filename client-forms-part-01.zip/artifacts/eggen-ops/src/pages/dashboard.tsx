import { useGetOpsStats, useListJobs, useListInvoices } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/crud";
import { Loader2, Users, MapPin, FileText, Briefcase, Receipt } from "lucide-react";
import { Link } from "wouter";

const JOB_STATUSES = ["Open", "Scheduled", "Complete", "Invoiced"] as const;

const jobStatusMap: Record<string, string> = {
  open: "bg-destructive/15 text-destructive",
  scheduled: "bg-secondary/20 text-secondary",
  complete: "bg-primary/15 text-primary",
  invoiced: "bg-muted text-muted-foreground",
};

function StatCard({ title, value, icon: Icon, description }: any) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="w-4 h-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && <p className="text-xs text-muted-foreground mt-1">{description}</p>}
      </CardContent>
    </Card>
  );
}

export function Dashboard() {
  const { data: stats, isLoading } = useGetOpsStats();
  const { data: jobs } = useListJobs();
  const { data: invoices } = useListInvoices();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const formatCurrency = (val: number | undefined) => 
    val ? new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(val) : "$0.00";

  const jobStatusCounts = (jobs ?? []).reduce<Record<string, number>>((acc, job) => {
    const key = (job.jobStatus || "Open").toLowerCase();
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const outstandingInvoiceCount = (invoices ?? []).filter(
    (inv) => (inv.balanceDue ?? 0) > 0,
  ).length;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Outstanding"
          value={formatCurrency(stats?.totalOutstanding)}
          icon={Receipt}
          description={`${outstandingInvoiceCount} outstanding ${outstandingInvoiceCount === 1 ? "invoice" : "invoices"}`}
        />
        <StatCard title="Total Customers" value={stats?.customerCount || 0} icon={Users} />
        <StatCard title="Properties" value={stats?.propertyCount || 0} icon={MapPin} />
        <StatCard title="Quotes" value={stats?.quoteCount || 0} icon={FileText} />
        <StatCard title="Jobs" value={stats?.jobCount || 0} icon={Briefcase} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-2">
          <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>Recent Jobs</CardTitle>
            <div className="flex flex-wrap items-center gap-2">
              {JOB_STATUSES.map((status) => (
                <Link
                  key={status}
                  href="/jobs"
                  className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs hover:bg-muted/50"
                >
                  <StatusBadge value={status} map={jobStatusMap} />
                  <span className="font-semibold tabular-nums">
                    {jobStatusCounts[status.toLowerCase()] || 0}
                  </span>
                </Link>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            {jobs?.length ? (
              <div className="space-y-4">
                {jobs.slice(0, 5).map(job => (
                  <div key={job.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div>
                      <div className="font-medium">{job.name || 'Unnamed Job'}</div>
                      <div className="text-sm text-muted-foreground">{job.address}</div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-sm px-2 py-1 bg-primary/10 text-primary rounded-full">
                        {job.jobStatus || 'Pending'}
                      </div>
                      <Link href={`/jobs/${job.id}`} className="text-sm text-primary hover:underline">
                        View
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground py-4 text-center">No recent jobs found.</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
