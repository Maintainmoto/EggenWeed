import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { Receipt, Loader2 } from "lucide-react";
import {
  useListJobs,
  useListProperties,
  useListCustomers,
  useCreateInvoice,
  getListInvoicesQueryKey,
  getListJobsQueryKey,
  type Job,
  type Property,
  type Customer,
} from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { formatDate, displayText } from "@/lib/format";

function isComplete(job: Job): boolean {
  return (job.jobStatus ?? "").trim().toLowerCase() === "complete";
}

function todayIso(): string {
  const d = new Date();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${month}-${day}`;
}

export function ReadyToInvoice() {
  const [, navigate] = useLocation();
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: jobs, isLoading: jobsLoading } = useListJobs();
  const { data: properties, isLoading: propsLoading } = useListProperties();
  const { data: customers, isLoading: custLoading } = useListCustomers();
  const create = useCreateInvoice();

  const isLoading = jobsLoading || propsLoading || custLoading;

  const propsById = useMemo(
    () => new Map((properties ?? []).map((p: Property) => [p.id, p])),
    [properties],
  );

  const customersById = useMemo(
    () => new Map((customers ?? []).map((c: Customer) => [c.id, c])),
    [customers],
  );

  // Build the bill-to contact block for an invoice from the job's property
  // (full address/phone) and its customer (email).
  const contactFor = (job: Job): Record<string, unknown> => {
    const prop = job.propertyId != null ? propsById.get(job.propertyId) : undefined;
    const customer =
      prop?.customerId != null ? customersById.get(prop.customerId) : undefined;
    const address = prop
      ? [prop.streetAddress, prop.unit].filter(Boolean).join(" ") || null
      : (job.address ?? null);
    return {
      address,
      city: prop?.city ?? job.city ?? null,
      state: prop?.state ?? null,
      zip: prop?.zip ?? null,
      phone: prop?.phone ?? null,
      email: customer?.email ?? null,
    };
  };

  const readyJobs = useMemo(
    () =>
      (jobs ?? [])
        .filter(isComplete)
        .slice()
        .sort((a, b) => (a.name ?? "").localeCompare(b.name ?? "")),
    [jobs],
  );

  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [totals, setTotals] = useState<Record<number, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Seed each row's Total from the job's amount (carried over from its quote)
  // so staff don't have to re-key it, while leaving any value they've edited.
  useEffect(() => {
    setTotals((prev) => {
      let changed = false;
      const next = { ...prev };
      for (const job of readyJobs) {
        if (next[job.id] === undefined && job.total != null) {
          next[job.id] = String(job.total);
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [readyJobs]);

  // Drop any selected ids that are no longer ready to invoice (e.g. after a
  // refetch following creation), so the count and button stay accurate.
  useEffect(() => {
    const ready = new Set(readyJobs.map((j) => j.id));
    setSelected((prev) => {
      const next = new Set(Array.from(prev).filter((id) => ready.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [readyJobs]);

  const customerNameFor = (job: Job): string => {
    const prop = job.propertyId != null ? propsById.get(job.propertyId) : undefined;
    return prop?.customerName ?? "";
  };

  const allSelected =
    readyJobs.length > 0 && readyJobs.every((j) => selected.has(j.id));
  const someSelected = selected.size > 0 && !allSelected;

  const toggleAll = () => {
    setSelected(allSelected ? new Set() : new Set(readyJobs.map((j) => j.id)));
  };

  const toggleOne = (id: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleCreate = async () => {
    const chosen = readyJobs.filter((j) => selected.has(j.id));
    if (chosen.length === 0) return;
    setSubmitting(true);
    let ok = 0;
    let failed = 0;
    for (const job of chosen) {
      const raw = totals[job.id]?.trim();
      const parsed = raw ? Number(raw) : null;
      const total = parsed != null && Number.isFinite(parsed) ? parsed : null;
      try {
        await create.mutateAsync({
          data: {
            jobId: job.id,
            customerName: customerNameFor(job) || null,
            ...contactFor(job),
            total,
            paymentStatus: "Not Sent",
            invoiceDate: todayIso(),
          },
        });
        ok += 1;
      } catch {
        failed += 1;
      }
    }
    await qc.invalidateQueries({ queryKey: getListInvoicesQueryKey() });
    await qc.invalidateQueries({ queryKey: getListJobsQueryKey() });
    setSelected(new Set());
    setTotals({});
    setSubmitting(false);

    if (failed === 0) {
      toast({
        title: `Created ${ok} invoice${ok === 1 ? "" : "s"}`,
        description: "The jobs are now marked Invoiced.",
      });
      navigate("/invoices");
    } else {
      toast({
        variant: "destructive",
        title: `Created ${ok}, ${failed} failed`,
        description: "Some invoices could not be created. Please retry.",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Ready to Invoice
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Completed jobs that haven&apos;t been invoiced yet. Select jobs and
            create invoices in one step.
          </p>
        </div>
        <Button
          onClick={handleCreate}
          disabled={selected.size === 0 || submitting || isLoading}
        >
          {submitting ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Receipt className="h-4 w-4 mr-2" />
          )}
          Create {selected.size > 0 ? selected.size : ""} Invoice
          {selected.size === 1 ? "" : "s"}
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin" />
            </div>
          ) : readyJobs.length === 0 ? (
            <p className="text-sm text-muted-foreground py-10 text-center">
              No completed jobs are waiting to be invoiced.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10">
                    <Checkbox
                      checked={
                        allSelected ? true : someSelected ? "indeterminate" : false
                      }
                      onCheckedChange={toggleAll}
                      aria-label="Select all"
                    />
                  </TableHead>
                  <TableHead>Job</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Address</TableHead>
                  <TableHead>Treat Date</TableHead>
                  <TableHead className="w-40">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {readyJobs.map((job) => {
                  const checked = selected.has(job.id);
                  return (
                    <TableRow key={job.id} data-state={checked ? "selected" : undefined}>
                      <TableCell>
                        <Checkbox
                          checked={checked}
                          onCheckedChange={() => toggleOne(job.id)}
                          aria-label={`Select job ${job.name ?? job.id}`}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        {displayText(job.name)}
                      </TableCell>
                      <TableCell>
                        {displayText(customerNameFor(job) || null)}
                      </TableCell>
                      <TableCell>{displayText(job.address)}</TableCell>
                      <TableCell>{formatDate(job.treatDate)}</TableCell>
                      <TableCell>
                        <div className="relative">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                            $
                          </span>
                          <Input
                            type="number"
                            inputMode="decimal"
                            min="0"
                            step="0.01"
                            placeholder="0.00"
                            className="pl-6"
                            value={totals[job.id] ?? ""}
                            onChange={(e) =>
                              setTotals((prev) => ({
                                ...prev,
                                [job.id]: e.target.value,
                              }))
                            }
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {readyJobs.length > 0 && (
        <div className="flex items-center justify-between">
          <Label className="text-sm text-muted-foreground">
            {selected.size} of {readyJobs.length} selected
          </Label>
          <Button
            onClick={handleCreate}
            disabled={selected.size === 0 || submitting || isLoading}
          >
            {submitting ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Receipt className="h-4 w-4 mr-2" />
            )}
            Create {selected.size > 0 ? selected.size : ""} Invoice
            {selected.size === 1 ? "" : "s"}
          </Button>
        </div>
      )}
    </div>
  );
}
