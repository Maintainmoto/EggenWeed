import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";
import { LoginPage } from "@/pages/login";
import { Dashboard } from "@/pages/dashboard";
import { Customers, CustomerDetail } from "@/pages/customers";
import { Properties, PropertyDetail } from "@/pages/properties";
import { Quotes, QuoteDetail } from "@/pages/quotes";
import { Jobs, JobDetail } from "@/pages/jobs";
import { Invoices, InvoiceDetail } from "@/pages/invoices";
import { ReadyToInvoice } from "@/pages/ready-to-invoice";
import { RouteSheets } from "@/pages/route-sheets";
import { RouteSheetEditor } from "@/pages/route-sheet-editor";
import { useGetAuthStatus, getGetAuthStatusQueryKey } from "@workspace/api-client-react";

const queryClient = new QueryClient();

function AuthGate({ children }: { children: React.ReactNode }) {
  const { data, isLoading } = useGetAuthStatus({
    query: { queryKey: getGetAuthStatusQueryKey(), retry: false },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data?.authenticated) {
    return <LoginPage />;
  }

  return <>{children}</>;
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/customers" component={Customers} />
        <Route path="/customers/:id">
          {(p) => <CustomerDetail id={Number(p.id)} />}
        </Route>
        <Route path="/properties" component={Properties} />
        <Route path="/properties/:id">
          {(p) => <PropertyDetail id={Number(p.id)} />}
        </Route>
        <Route path="/quotes" component={Quotes} />
        <Route path="/quotes/:id">
          {(p) => <QuoteDetail id={Number(p.id)} />}
        </Route>
        <Route path="/jobs" component={Jobs} />
        <Route path="/jobs/:id">{(p) => <JobDetail id={Number(p.id)} />}</Route>
        <Route path="/ready-to-invoice" component={ReadyToInvoice} />
        <Route path="/invoices" component={Invoices} />
        <Route path="/invoices/:id">
          {(p) => <InvoiceDetail id={Number(p.id)} />}
        </Route>
        <Route path="/route-sheets" component={RouteSheets} />
        <Route path="/route-sheets/new" component={RouteSheetEditor} />
        <Route path="/route-sheets/:id" component={RouteSheetEditor} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthGate>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
        </AuthGate>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
