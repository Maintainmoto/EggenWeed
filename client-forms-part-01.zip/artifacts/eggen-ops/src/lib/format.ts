export function formatCurrency(val?: number | null): string {
  if (val == null) return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(val);
}

export function formatDate(val?: string | null): string {
  if (!val) return "—";
  const d = new Date(val.length <= 10 ? `${val}T00:00:00` : val);
  if (Number.isNaN(d.getTime())) return val;
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function displayText(val?: string | number | null): string {
  if (val == null || val === "") return "—";
  return String(val);
}
