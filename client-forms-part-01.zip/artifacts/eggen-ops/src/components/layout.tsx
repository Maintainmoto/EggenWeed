import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { 
  LayoutDashboard, 
  Users, 
  MapPin, 
  FileText, 
  Briefcase, 
  Receipt,
  FileCheck,
  Route as RouteIcon,
  LogOut,
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLogout, getGetAuthStatusQueryKey } from "@workspace/api-client-react";
import { useState } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const logout = useLogout({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      }
    }
  });

  const [mobileOpen, setMobileOpen] = useState(false);

  const nav = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/customers", label: "Customers", icon: Users },
    { href: "/properties", label: "Properties", icon: MapPin },
    { href: "/quotes", label: "Quotes", icon: FileText },
    { href: "/jobs", label: "Jobs", icon: Briefcase },
    { href: "/ready-to-invoice", label: "Ready to Invoice", icon: FileCheck },
    { href: "/invoices", label: "Invoices", icon: Receipt },
    { href: "/route-sheets", label: "Route Sheets", icon: RouteIcon },
  ];

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile sidebar toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50 no-print">
        <Button variant="outline" size="icon" onClick={() => setMobileOpen(!mobileOpen)}>
          <Menu className="h-5 w-5" />
        </Button>
      </div>

      {/* Sidebar */}
      <aside className={`
        no-print
        fixed inset-y-0 left-0 z-40 w-64 bg-sidebar border-r border-sidebar-border transform transition-transform duration-200 ease-in-out
        ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
        md:relative md:translate-x-0
      `}>
        <div className="h-full flex flex-col">
          <div className="h-16 flex items-center px-6 border-b border-sidebar-border gap-3">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold text-lg">
              E
            </div>
            <span className="font-semibold text-lg tracking-tight">Eggen Ops</span>
          </div>

          <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
            {nav.map((item) => {
              const active = location === item.href || (item.href !== "/" && location.startsWith(item.href));
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} onClick={() => setMobileOpen(false)}>
                  <div className={`
                    flex items-center gap-3 px-3 py-2 rounded-md transition-colors cursor-pointer
                    ${active 
                      ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium" 
                      : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"}
                  `}>
                    <Icon className="h-5 w-5" />
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </nav>

          <div className="p-4 border-t border-sidebar-border">
            <Button 
              variant="ghost" 
              className="w-full justify-start text-muted-foreground hover:text-foreground"
              onClick={() => logout.mutate()}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pt-16 md:pt-8">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </div>
      </main>
      
      {/* Mobile overlay */}
      {mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/20 z-30 md:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}
    </div>
  );
}
