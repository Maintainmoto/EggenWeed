import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import {
  Loader2,
  Pencil,
  Trash2,
  Plus,
  Search,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { formatCurrency, formatDate, displayText } from "@/lib/format";

export type FieldSpec = {
  name: string;
  label: string;
  type?: "text" | "number" | "date" | "textarea" | "select" | "relation";
  options?: { value: string; label: string }[];
  nameField?: string;
  currency?: boolean;
  full?: boolean;
  quickCreate?: {
    title: string;
    fields: FieldSpec[];
    onCreate: (
      data: Record<string, unknown>,
    ) => Promise<{
      id: number;
      label: string;
      merge?: Record<string, unknown>;
    }>;
  };
  quickCreateInitial?: (
    values: Record<string, unknown>,
  ) => Record<string, unknown>;
  onSelect?: (id: number | null) => Record<string, unknown> | undefined;
  optionsFor?: (
    values: Record<string, unknown>,
  ) => { value: string; label: string }[];
  defaultValue?: unknown;
};

export type Column<T> = {
  key: string;
  header: string;
  render?: (row: T) => React.ReactNode;
  className?: string;
  filterable?: boolean;
  filterType?: "select" | "dateRange";
  sortable?: boolean;
};

export function StatusBadge({
  value,
  map,
}: {
  value?: string | null;
  map?: Record<string, string>;
}) {
  if (!value) return <span className="text-muted-foreground">—</span>;
  const cls = map?.[value.toLowerCase()] ?? "bg-muted text-foreground";
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}
    >
      {value}
    </span>
  );
}

export const paymentStatusMap: Record<string, string> = {
  "not sent": "bg-muted text-muted-foreground",
  sent: "bg-secondary/20 text-secondary",
  "partially paid": "bg-amber-100 text-amber-800",
  paid: "bg-primary/15 text-primary",
};

function fieldDisplayValue(f: FieldSpec, row: Record<string, unknown>): React.ReactNode {
  if (f.type === "relation") {
    const id = row[f.name];
    if (id == null) return displayText(row[f.nameField ?? ""] as string);
    const opt = f.options?.find((o) => o.value === String(id));
    if (opt) return opt.label;
    return displayText(
      (row[f.nameField ?? ""] as string) ?? `#${String(id)}`,
    );
  }
  const raw = row[f.name];
  if (f.currency) return formatCurrency(raw as number | null);
  if (f.type === "date") return formatDate(raw as string | null);
  return displayText(raw as string | number | null);
}

export function EntityFormDialog({
  open,
  onOpenChange,
  title,
  fields,
  initial,
  onSubmit,
  isPending,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title: string;
  fields: FieldSpec[];
  initial: Record<string, unknown>;
  onSubmit: (values: Record<string, unknown>) => void;
  isPending?: boolean;
}) {
  const applyDefaults = (init: Record<string, unknown>) => {
    if (init.id != null) return init;
    const v = { ...init };
    for (const f of fields) {
      if (
        f.defaultValue !== undefined &&
        (v[f.name] === undefined || v[f.name] === null || v[f.name] === "")
      ) {
        v[f.name] = f.defaultValue;
      }
    }
    return v;
  };

  const [values, setValues] = useState<Record<string, unknown>>(() =>
    applyDefaults(initial),
  );

  useEffect(() => {
    if (open) setValues(applyDefaults(initial));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const set = (name: string, v: unknown) =>
    setValues((prev) => ({ ...prev, [name]: v }));

  const handleSubmit = () => {
    const payload: Record<string, unknown> = {};
    for (const f of fields) {
      let v = values[f.name];
      if (v === "" || v === undefined) v = null;
      payload[f.name] = v;
      if (f.type === "relation" && f.nameField) {
        payload[f.nameField] = values[f.nameField] ?? null;
      }
    }
    onSubmit(payload);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
          {fields.map((f) => {
            const wide = f.full || f.type === "textarea";
            const opts = f.optionsFor ? f.optionsFor(values) : f.options;
            return (
              <div
                key={f.name}
                className={`space-y-1.5 ${wide ? "sm:col-span-2" : ""}`}
              >
                <Label htmlFor={f.name}>{f.label}</Label>
                {f.type === "textarea" ? (
                  <Textarea
                    id={f.name}
                    value={(values[f.name] as string) ?? ""}
                    onChange={(e) => set(f.name, e.target.value)}
                  />
                ) : f.type === "select" ? (
                  <Select
                    value={(values[f.name] as string) ?? ""}
                    onValueChange={(v) => set(f.name, v)}
                  >
                    <SelectTrigger id={f.name}>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      {opts?.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : f.type === "relation" ? (
                  <RelationField
                    f={f.optionsFor ? { ...f, options: opts } : f}
                    value={values[f.name]}
                    quickCreateInitial={f.quickCreateInitial?.(values)}
                    onChange={(id, label, merge) => {
                      const extra = merge ?? f.onSelect?.(id);
                      setValues((prev) => ({
                        ...prev,
                        [f.name]: id,
                        ...(f.nameField ? { [f.nameField]: label } : {}),
                        ...(extra ?? {}),
                      }));
                    }}
                  />
                ) : (
                  <Input
                    id={f.name}
                    type={
                      f.type === "number"
                        ? "number"
                        : f.type === "date"
                          ? "date"
                          : "text"
                    }
                    value={(values[f.name] as string | number) ?? ""}
                    onChange={(e) =>
                      set(
                        f.name,
                        f.type === "number"
                          ? e.target.value === ""
                            ? null
                            : Number(e.target.value)
                          : e.target.value,
                      )
                    }
                  />
                )}
              </div>
            );
          })}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isPending}>
            {isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RelationField({
  f,
  value,
  onChange,
  quickCreateInitial,
}: {
  f: FieldSpec;
  value: unknown;
  onChange: (
    id: number | null,
    label: string | null,
    merge?: Record<string, unknown>,
  ) => void;
  quickCreateInitial?: Record<string, unknown>;
}) {
  const [qcOpen, setQcOpen] = useState(false);
  const [qcPending, setQcPending] = useState(false);
  const [extra, setExtra] = useState<{ value: string; label: string }[]>([]);

  const baseOptions = f.options ?? [];
  const options = [
    ...baseOptions,
    ...extra.filter((e) => !baseOptions.some((o) => o.value === e.value)),
  ];

  const handleQuickCreate = async (data: Record<string, unknown>) => {
    if (!f.quickCreate) return;
    setQcPending(true);
    try {
      const res = await f.quickCreate.onCreate(data);
      setExtra((prev) => [
        ...prev,
        { value: String(res.id), label: res.label },
      ]);
      onChange(res.id, res.label, res.merge);
      setQcOpen(false);
    } catch {
      /* keep dialog open; error surfaced by mutation */
    } finally {
      setQcPending(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Select
        value={value != null ? String(value) : ""}
        onValueChange={(v) => {
          const opt = options.find((o) => o.value === v);
          onChange(v ? Number(v) : null, opt?.label ?? null);
        }}
      >
        <SelectTrigger id={f.name} className="flex-1">
          <SelectValue placeholder="Select..." />
        </SelectTrigger>
        <SelectContent>
          {options.map((o) => (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {f.quickCreate && (
        <>
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="shrink-0"
            title={f.quickCreate.title}
            onClick={() => setQcOpen(true)}
          >
            <Plus className="h-4 w-4" />
          </Button>
          <EntityFormDialog
            open={qcOpen}
            onOpenChange={setQcOpen}
            title={f.quickCreate.title}
            fields={f.quickCreate.fields}
            initial={quickCreateInitial ?? {}}
            onSubmit={handleQuickCreate}
            isPending={qcPending}
          />
        </>
      )}
    </div>
  );
}

function DeleteButton({
  onConfirm,
  label,
}: {
  onConfirm: () => void;
  label: string;
}) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-muted-foreground hover:text-destructive"
          onClick={(e) => e.stopPropagation()}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent onClick={(e) => e.stopPropagation()}>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {label}?</AlertDialogTitle>
          <AlertDialogDescription>
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

export function CrudList<T extends { id: number }>({
  title,
  singular,
  rows,
  isLoading,
  columns,
  fields,
  searchKeys,
  detailPath,
  onCreate,
  onUpdate,
  onDelete,
  isMutating,
}: {
  title: string;
  singular: string;
  rows: T[];
  isLoading?: boolean;
  columns: Column<T>[];
  fields: FieldSpec[];
  searchKeys: string[];
  detailPath: string;
  onCreate: (data: Record<string, unknown>) => Promise<unknown>;
  onUpdate: (id: number, data: Record<string, unknown>) => Promise<unknown>;
  onDelete: (id: number) => Promise<unknown>;
  isMutating?: boolean;
}) {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [dateRanges, setDateRanges] = useState<
    Record<string, { from?: string; to?: string }>
  >({});
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<T | null>(null);
  const [sort, setSort] = useState<{ key: string; dir: "asc" | "desc" } | null>(
    null,
  );

  const toggleSort = (key: string) =>
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, dir: "asc" };
      if (prev.dir === "asc") return { key, dir: "desc" };
      return null;
    });

  const ALL = "__all__";
  const filterCols = columns.filter((c) => c.filterable);
  const selectCols = filterCols.filter((c) => c.filterType !== "dateRange");
  const dateRangeCols = filterCols.filter((c) => c.filterType === "dateRange");
  const distinctValues = (key: string) =>
    Array.from(
      new Set(
        rows
          .map((r) => String((r as Record<string, unknown>)[key] ?? "").trim())
          .filter((v) => v !== ""),
      ),
    ).sort((a, b) => a.localeCompare(b));
  const activeFilterCount =
    Object.values(filters).filter((v) => v && v !== ALL).length +
    Object.values(dateRanges).filter((r) => r.from || r.to).length;

  useEffect(() => {
    setFilters((prev) => {
      let changed = false;
      const next: Record<string, string> = {};
      for (const [key, val] of Object.entries(prev)) {
        if (val === ALL || distinctValues(key).includes(val)) {
          next[key] = val;
        } else {
          changed = true;
        }
      }
      return changed ? next : prev;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows]);

  const clearAllFilters = () => {
    setFilters({});
    setDateRanges({});
  };

  const filtered = rows.filter((r) => {
    const rec = r as Record<string, unknown>;
    if (search.trim()) {
      const q = search.toLowerCase();
      const hit = searchKeys.some((k) =>
        String(rec[k] ?? "")
          .toLowerCase()
          .includes(q),
      );
      if (!hit) return false;
    }
    for (const c of selectCols) {
      const sel = filters[c.key];
      if (
        sel &&
        sel !== ALL &&
        String(rec[c.key] ?? "")
          .trim()
          .toLowerCase() !== sel.toLowerCase()
      ) {
        return false;
      }
    }
    for (const c of dateRangeCols) {
      const range = dateRanges[c.key];
      if (!range || (!range.from && !range.to)) continue;
      const val = String(rec[c.key] ?? "").trim();
      if (!val) return false;
      if (range.from && val < range.from) return false;
      if (range.to && val > range.to) return false;
    }
    return true;
  });

  const sorted = sort
    ? [...filtered].sort((a, b) => {
        const av = (a as Record<string, unknown>)[sort.key];
        const bv = (b as Record<string, unknown>)[sort.key];
        let cmp: number;
        if (typeof av === "number" && typeof bv === "number") {
          cmp = av - bv;
        } else {
          cmp = String(av ?? "").localeCompare(String(bv ?? ""), undefined, {
            numeric: true,
            sensitivity: "base",
          });
        }
        return sort.dir === "asc" ? cmp : -cmp;
      })
    : filtered;

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };
  const openEdit = (row: T) => {
    setEditing(row);
    setDialogOpen(true);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    try {
      if (editing) await onUpdate(editing.id, data);
      else await onCreate(data);
      setDialogOpen(false);
    } catch {
      /* error surfaced by mutation */
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4 mr-2" />
          New {singular}
        </Button>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${title.toLowerCase()}...`}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        {selectCols.map((c) => {
          const values = distinctValues(c.key);
          if (values.length === 0) return null;
          return (
            <div key={c.key} className="flex flex-col gap-1">
              <span className="text-xs font-medium text-muted-foreground">
                {c.header}
              </span>
              <Select
                value={filters[c.key] ?? ALL}
                onValueChange={(v) =>
                  setFilters((prev) => ({ ...prev, [c.key]: v }))
                }
              >
                <SelectTrigger className="h-9 w-40">
                  <SelectValue placeholder={`All ${c.header}`} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={ALL}>All {c.header}</SelectItem>
                  {values.map((v) => (
                    <SelectItem key={v} value={v}>
                      {v}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          );
        })}
        {dateRangeCols.map((c) => (
          <div key={c.key} className="flex flex-col gap-1">
            <span className="text-xs font-medium text-muted-foreground">
              {c.header}
            </span>
            <div className="flex items-center gap-2">
              <Input
                type="date"
                aria-label={`${c.header} from`}
                value={dateRanges[c.key]?.from ?? ""}
                onChange={(e) =>
                  setDateRanges((prev) => ({
                    ...prev,
                    [c.key]: { ...prev[c.key], from: e.target.value },
                  }))
                }
                className="h-9 w-40"
              />
              <span className="text-muted-foreground text-sm">to</span>
              <Input
                type="date"
                aria-label={`${c.header} to`}
                value={dateRanges[c.key]?.to ?? ""}
                onChange={(e) =>
                  setDateRanges((prev) => ({
                    ...prev,
                    [c.key]: { ...prev[c.key], to: e.target.value },
                  }))
                }
                className="h-9 w-40"
              />
            </div>
          </div>
        ))}
        {activeFilterCount > 0 && (
          <Button
            variant="ghost"
            className="h-9 text-muted-foreground"
            onClick={clearAllFilters}
          >
            Clear filters
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-48">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center text-muted-foreground py-16">
              {rows.length === 0
                ? `No ${title.toLowerCase()} yet. Create your first ${singular.toLowerCase()}.`
                : "No matches found."}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  {columns.map((c) => (
                    <TableHead key={c.key} className={c.className}>
                      {c.sortable ? (
                        <button
                          type="button"
                          onClick={() => toggleSort(c.key)}
                          className="inline-flex items-center gap-1 hover:text-foreground"
                        >
                          {c.header}
                          {sort?.key === c.key ? (
                            sort.dir === "asc" ? (
                              <ArrowUp className="h-3.5 w-3.5" />
                            ) : (
                              <ArrowDown className="h-3.5 w-3.5" />
                            )
                          ) : (
                            <ArrowUpDown className="h-3.5 w-3.5 opacity-40" />
                          )}
                        </button>
                      ) : (
                        c.header
                      )}
                    </TableHead>
                  ))}
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sorted.map((row) => (
                  <TableRow
                    key={row.id}
                    className="cursor-pointer"
                    onClick={() => navigate(`${detailPath}/${row.id}`)}
                  >
                    {columns.map((c) => (
                      <TableCell key={c.key} className={c.className}>
                        {c.render
                          ? c.render(row)
                          : displayText(
                              (row as Record<string, unknown>)[c.key] as
                                | string
                                | number
                                | null,
                            )}
                      </TableCell>
                    ))}
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-muted-foreground hover:text-foreground"
                          onClick={(e) => {
                            e.stopPropagation();
                            openEdit(row);
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <DeleteButton
                          label={singular.toLowerCase()}
                          onConfirm={() => onDelete(row.id)}
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <EntityFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={editing ? `Edit ${singular}` : `New ${singular}`}
        fields={fields}
        initial={editing ? (editing as Record<string, unknown>) : {}}
        onSubmit={handleSubmit}
        isPending={isMutating}
      />
    </div>
  );
}

export function CrudDetail<T extends { id: number }>({
  singular,
  backPath,
  titleKeys,
  row,
  isLoading,
  fields,
  extraDisplay,
  onUpdate,
  onDelete,
  isMutating,
}: {
  singular: string;
  backPath: string;
  titleKeys: string[];
  row: T | undefined;
  isLoading?: boolean;
  fields: FieldSpec[];
  extraDisplay?: { label: string; value: React.ReactNode }[];
  onUpdate: (id: number, data: Record<string, unknown>) => Promise<unknown>;
  onDelete: (id: number) => Promise<unknown>;
  isMutating?: boolean;
}) {
  const [, navigate] = useLocation();
  const [editOpen, setEditOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!row) {
    return (
      <div className="space-y-4">
        <p className="text-muted-foreground">{singular} not found.</p>
        <Button variant="outline" onClick={() => navigate(backPath)}>
          Back
        </Button>
      </div>
    );
  }

  const r = row as Record<string, unknown>;
  const title =
    titleKeys
      .map((k) => r[k])
      .find((v) => v != null && v !== "") ?? `${singular} #${row.id}`;

  const handleSubmit = async (data: Record<string, unknown>) => {
    try {
      await onUpdate(row.id, data);
      setEditOpen(false);
    } catch {
      /* error surfaced by mutation */
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={() => navigate(backPath)}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            ← Back
          </button>
          <h1 className="text-3xl font-bold tracking-tight mt-1">
            {String(title)}
          </h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setEditOpen(true)}>
            <Pencil className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <DeleteButton
            label={singular.toLowerCase()}
            onConfirm={async () => {
              await onDelete(row.id);
              navigate(backPath);
            }}
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
            {extraDisplay?.map((d) => (
              <div key={d.label} className="space-y-0.5">
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  {d.label}
                </dt>
                <dd className="text-sm font-medium">{d.value}</dd>
              </div>
            ))}
            {fields.map((f) => (
              <div
                key={f.name}
                className={`space-y-0.5 ${f.type === "textarea" ? "sm:col-span-2" : ""}`}
              >
                <dt className="text-xs uppercase tracking-wide text-muted-foreground">
                  {f.label}
                </dt>
                <dd className="text-sm font-medium whitespace-pre-wrap">
                  {fieldDisplayValue(f, r)}
                </dd>
              </div>
            ))}
          </dl>
        </CardContent>
      </Card>

      <EntityFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        title={`Edit ${singular}`}
        fields={fields}
        initial={r}
        onSubmit={handleSubmit}
        isPending={isMutating}
      />
    </div>
  );
}
