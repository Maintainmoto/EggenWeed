import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { useForm, type UseFormRegister } from "react-hook-form";
import { useQueryClient } from "@tanstack/react-query";
import { Printer, Save, Trash2, ArrowLeft, Loader2 } from "lucide-react";
import Logo from "@assets/Logo_1781823781016.png";

import { Button } from "@/components/ui/button";
import { InvoicePrintSheet } from "@/components/invoice-print";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

import {
  useGetDocument,
  useGetNextDocumentNumber,
  useCreateDocument,
  useUpdateDocument,
  useDeleteDocument,
  getListDocumentsQueryKey,
  getGetDocumentStatsQueryKey,
  getGetDocumentQueryKey,
  getGetNextDocumentNumberQueryKey,
  DocumentType,
} from "@workspace/api-client-react";

interface DocumentEditorProps {
  type: "invoice" | "quote";
}

const defaultValues = {
  name: "", address: "", city: "", zip: "", homePhone: "", workPhone: "", otherPhone: "",
  billToName: "", billToAddress: "", billToCity: "", billToZip: "", billToHome: "", billToOffice: "", billToOther: "", billToContact: "",
  scheduleContact: "", grid: "", time: "", estimate: "", idNumber: "", ratio: "", confirm: "", salesPerson: "", treatDate: "",
  memo: "", specialInstructions: "", checkNumber: "", poNumber: "", total: "", jobDescription: "", travelInstructions: "",
  printName: "", signatureDate: ""
};


export function DocumentEditor({ type }: DocumentEditorProps) {
  const params = useParams<{ id?: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const isNew = !params.id || params.id === "new";
  const documentId = isNew ? null : parseInt(params.id!, 10);

  const { data: document, isLoading: isLoadingDoc } = useGetDocument(documentId as number, {
    query: { enabled: !!documentId, queryKey: getGetDocumentQueryKey(documentId as number) }
  });

  const { data: nextNumber, isLoading: isLoadingNumber } = useGetNextDocumentNumber({ type: type as DocumentType }, {
    query: { enabled: isNew, queryKey: getGetNextDocumentNumberQueryKey({ type: type as DocumentType }) }
  });

  const createMutation = useCreateDocument({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDocumentStatsQueryKey() });
        toast({ title: "Document created successfully" });
        setLocation(`/${type}s/${data.id}`);
      },
      onError: () => toast({ title: "Failed to create document", variant: "destructive" })
    }
  });

  const updateMutation = useUpdateDocument({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() });
        queryClient.setQueryData(getGetDocumentQueryKey(data.id), data);
        toast({ title: "Document updated successfully" });
      },
      onError: () => toast({ title: "Failed to update document", variant: "destructive" })
    }
  });

  const deleteMutation = useDeleteDocument({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDocumentStatsQueryKey() });
        toast({ title: "Document deleted" });
        setLocation("/");
      },
      onError: () => toast({ title: "Failed to delete document", variant: "destructive" })
    }
  });

  const form = useForm({
    defaultValues: {
      type: type as DocumentType,
      ...defaultValues
    }
  });

  const initializedRef = useRef<number | null>(null);

  useEffect(() => {
    if (document && initializedRef.current !== document.id) {
      initializedRef.current = document.id;
      form.reset({
        type: document.type,
        name: document.name || "", address: document.address || "", city: document.city || "", zip: document.zip || "",
        homePhone: document.homePhone || "", workPhone: document.workPhone || "", otherPhone: document.otherPhone || "",
        billToName: document.billToName || "", billToAddress: document.billToAddress || "", billToCity: document.billToCity || "",
        billToZip: document.billToZip || "", billToHome: document.billToHome || "", billToOffice: document.billToOffice || "",
        billToOther: document.billToOther || "", billToContact: document.billToContact || "", scheduleContact: document.scheduleContact || "",
        grid: document.grid || "", time: document.time || "", estimate: document.estimate || "", idNumber: document.idNumber || "",
        ratio: document.ratio || "", confirm: document.confirm || "", salesPerson: document.salesPerson || "", treatDate: document.treatDate || "",
        memo: document.memo || "", specialInstructions: document.specialInstructions || "", checkNumber: document.checkNumber || "",
        poNumber: document.poNumber || "", total: document.total || "", jobDescription: document.jobDescription || "",
        travelInstructions: document.travelInstructions || "", printName: document.printName || "", signatureDate: document.signatureDate || ""
      });
    }
  }, [document, form]);

  useEffect(() => {
    if (isNew) {
      initializedRef.current = null;
      form.reset({
        type: type as DocumentType,
        ...defaultValues
      });
    }
  }, [isNew, type, form]);

  const onSubmit = (values: any) => {
    // Nullify empty strings to match API
    const data = Object.fromEntries(
      Object.entries(values).map(([k, v]) => [k, v === "" ? null : v])
    );
    data.type = type;

    if (isNew) {
      createMutation.mutate({ data: data as any });
    } else {
      updateMutation.mutate({ id: documentId!, data: data as any });
    }
  };

  const handleDelete = () => {
    if (documentId && confirm("Are you sure you want to delete this document?")) {
      deleteMutation.mutate({ id: documentId });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if ((!isNew && isLoadingDoc) || (isNew && isLoadingNumber)) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-[800px] w-full" />
      </div>
    );
  }

  const currentNumber = isNew ? nextNumber?.number : document?.docNumber;
  const isSaving = createMutation.isPending || updateMutation.isPending;
  const values = form.watch();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between no-print mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setLocation("/")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold tracking-tight capitalize">{isNew ? `New ${type}` : `Edit ${type}`}</h1>
        </div>
        <div className="flex items-center gap-2">
          {!isNew && (
            <Button variant="destructive" size="icon" onClick={handleDelete} disabled={deleteMutation.isPending}>
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
          <Button variant="secondary" onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button onClick={form.handleSubmit(onSubmit)} disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save
          </Button>
        </div>
      </div>

      {/* Interactive editor (screen only) */}
      <div
        className="no-print bg-white text-black p-8 mx-auto shadow-sm border rounded-lg"
        style={{ maxWidth: "8.5in" }}
      >
        <form className="space-y-4">
          <FormContent
            mode="edit"
            type={type}
            currentNumber={currentNumber}
            values={values}
            register={form.register}
          />
        </form>
      </div>

      {/* Print-only carbonless copies — one full page each */}
      <div className="hidden print:block print-sheets">
        {(type === "invoice"
          ? (["part1", "part2", "part2"] as const)
          : (["quote", "quote", "quote"] as const)
        ).map((variant, i) => (
          <div key={i} className={i < 2 ? "print-break-after" : ""}>
            <InvoicePrintSheet
              variant={variant}
              values={values}
              number={currentNumber}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

interface FormContentProps {
  mode: "edit" | "print";
  type: "invoice" | "quote";
  currentNumber: number | string | undefined;
  values: Record<string, any>;
  register: UseFormRegister<any>;
  copyLabel?: string;
}

function FormContent({ mode, type, currentNumber, values, register, copyLabel }: FormContentProps) {
  const isPrint = mode === "print";

  // Underlined field (used inside the form boxes). Print stays single-line and
  // clips overflow so a long value can never grow a row and push past one page.
  const field = (name: string, cls: string) =>
    isPrint ? (
      <span className={`${cls} border-b border-black text-sm leading-5 h-5 block overflow-hidden whitespace-nowrap`}>
        {values[name] || "\u00A0"}
      </span>
    ) : (
      <input
        className={`${cls} border-b border-gray-300 print:border-black outline-none bg-transparent`}
        {...register(name)}
      />
    );

  // Plain cell (no underline) used in bordered cells like Check/PO/Total and Travel
  const cell = (name: string, cls: string) =>
    isPrint ? (
      <div className={`${cls} flex items-center overflow-hidden whitespace-nowrap`}>{values[name] || ""}</div>
    ) : (
      <input className={`${cls} outline-none bg-transparent`} {...register(name)} />
    );

  // Multi-line area used in Memo / Special Instructions / Job Description. Print
  // clips to the box height (matching the textarea) so it never overflows the page.
  const area = (name: string, cls: string) =>
    isPrint ? (
      <div className={`${cls} whitespace-pre-wrap break-words overflow-hidden`}>{values[name] || ""}</div>
    ) : (
      <textarea className={`${cls} outline-none resize-none bg-transparent`} {...register(name)} />
    );

  return (
    <>
      {copyLabel && (
        <div className="flex justify-end mb-2">
          <span className="border border-black px-2 py-0.5 text-xs font-bold uppercase tracking-widest text-black">
            {copyLabel}
          </span>
        </div>
      )}

      {/* Header — matches the invoice print header format */}
      <div className="relative flex justify-between items-start mb-6">
        <div className="absolute top-0 right-0 text-[16pt] text-[#c0272d]">
          {currentNumber || ""}
        </div>
        <div className="w-1/3">
          <img src={Logo} alt="Eggen Weed Control" className="w-32 mb-2" />
        </div>
        <div
          className="text-center leading-tight font-bold"
          style={{ fontFamily: "'Bookman Old Style', Bookman, Georgia, serif" }}
        >
          <div className="text-[24pt] leading-[1.15]">(602) 996-1000</div>
          <div className="text-[15pt] leading-[1.2]">7619 E. Greenway Rd., Ste. 800</div>
          <div className="text-[15pt] leading-[1.2]">Scottsdale, Arizona 85260</div>
        </div>
        <div className="w-1/3" />
      </div>

      {/* Row 1: Customer & Schedule */}
      <div className="flex gap-4">
        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Customer</div>
          <div className="p-2 space-y-1 text-sm">
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Name</span>
              {field("name", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Address</span>
              {field("address", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">City</span>
              {field("city", "flex-1 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Zip</span>
              {field("zip", "w-20 min-w-0")}
            </div>
            <div className="flex gap-2 pt-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Home Phone</span>
              {field("homePhone", "w-24 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Work</span>
              {field("workPhone", "w-24 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Other</span>
              {field("otherPhone", "flex-1 min-w-0")}
            </div>
          </div>
        </div>

        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Schedule Instructions</div>
          <div className="p-2 space-y-1 text-sm flex-1">
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Contact</span>
              {field("scheduleContact", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Grid</span>
              {field("grid", "w-16 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Time</span>
              {field("time", "w-16 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Estimate</span>
              {field("estimate", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">I.D. #</span>
              {field("idNumber", "w-16 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Ratio</span>
              {field("ratio", "w-16 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Confirm</span>
              {field("confirm", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2 pt-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-20 pt-1">Sales Person</span>
              {field("salesPerson", "flex-1 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Treat Date</span>
              {field("treatDate", "w-24 min-w-0")}
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Bill To & Info */}
      <div className="flex gap-4">
        <div className="w-1/2 border print-border border-black flex flex-col">
          <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Bill To</div>
          <div className="p-2 space-y-1 text-sm">
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Name</span>
              {field("billToName", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Address</span>
              {field("billToAddress", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">City</span>
              {field("billToCity", "flex-1 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Zip</span>
              {field("billToZip", "w-20 min-w-0")}
            </div>
            <div className="flex gap-2 pt-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Home Phone</span>
              {field("billToHome", "w-20 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Office</span>
              {field("billToOffice", "w-20 min-w-0")}
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap pt-1">Other</span>
              {field("billToOther", "flex-1 min-w-0")}
            </div>
            <div className="flex gap-2">
              <span className="text-[10px] uppercase font-semibold shrink-0 whitespace-nowrap w-16 pt-1">Contact</span>
              {field("billToContact", "flex-1 min-w-0")}
            </div>
          </div>
        </div>

        <div className="w-1/2 flex flex-col gap-2">
          <div className="flex gap-2 flex-1">
            <div className="w-1/2 border print-border border-black flex flex-col">
              <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Memo</div>
              {area("memo", "w-full h-full min-h-[6rem] p-2 text-sm")}
            </div>
            <div className="w-1/2 border print-border border-black flex flex-col">
              <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Special Instructions</div>
              {area("specialInstructions", "w-full h-full min-h-[6rem] p-2 text-sm")}
            </div>
          </div>
          <div className="flex gap-2 h-8">
            <div className="flex-1 flex border print-border border-black items-center">
              <div className="text-[10px] font-bold uppercase border-r print-border-r border-black bg-gray-100 print:bg-transparent px-2 h-full flex items-center w-20">Check #</div>
              {cell("checkNumber", "w-full h-full px-2 text-sm")}
            </div>
            <div className="flex-1 flex border print-border border-black items-center">
              <div className="text-[10px] font-bold uppercase border-r print-border-r border-black bg-gray-100 print:bg-transparent px-2 h-full flex items-center w-16">P.O. #</div>
              {cell("poNumber", "w-full h-full px-2 text-sm")}
            </div>
            <div className="flex-1 flex border print-border border-black items-center">
              <div className="text-[10px] font-bold uppercase border-r print-border-r border-black bg-gray-100 print:bg-transparent px-2 h-full flex items-center w-16">Total $</div>
              {cell("total", "w-full h-full px-2 text-sm font-bold")}
            </div>
          </div>
        </div>
      </div>

      {/* Job Description */}
      <div className="border print-border border-black flex flex-col h-64 mt-4">
        <div className="text-[10px] font-bold uppercase border-b print-border-b border-black bg-gray-100 print:bg-transparent px-2 py-0.5">Job Description</div>
        {area("jobDescription", "w-full h-full p-2 text-sm")}
      </div>

      {/* Travel Instructions */}
      <div className="border print-border border-black flex mt-4 items-center">
        <div className="text-[10px] font-bold uppercase border-r print-border-r border-black bg-gray-100 print:bg-transparent px-2 py-1 w-36 shrink-0 h-full flex items-center">Travel Instructions</div>
        {cell("travelInstructions", "w-full px-2 py-1 text-sm")}
      </div>

      {/* Footer Text / Signatures based on type */}
      <div className="mt-8 text-center text-sm">
        {type === "invoice" && (
          <div className="font-bold italic">Payable upon receipt — Thank you.</div>
        )}
      </div>
    </>
  );
}
