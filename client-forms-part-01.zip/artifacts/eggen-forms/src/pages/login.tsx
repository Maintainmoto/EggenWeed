import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import Logo from "@assets/Logo_1781823781016.png";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLogin, getGetAuthStatusQueryKey } from "@workspace/api-client-react";

export function LoginPage() {
  const queryClient = useQueryClient();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const loginMutation = useLogin({
    mutation: {
      onSuccess: () => {
        setError(null);
        queryClient.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      },
      onError: () => {
        setError("Incorrect password. Please try again.");
        setPassword("");
      },
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;
    loginMutation.mutate({ data: { password } });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm">
        <div className="flex justify-center mb-8">
          <img
            src={Logo}
            alt="Eggen Weed Control"
            className="w-56 h-auto object-contain bg-white p-3 rounded-lg shadow-sm"
          />
        </div>

        <div className="bg-card border rounded-lg shadow-sm p-6">
          <h1 className="text-lg font-semibold text-center mb-1">Eggen Weed Control Forms</h1>
          <p className="text-sm text-muted-foreground text-center mb-6">
            Enter the office password to continue.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Office Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                autoFocus
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="••••••••"
              />
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}

            <Button type="submit" className="w-full" disabled={loginMutation.isPending || !password}>
              {loginMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Sign In
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
