import type { CSSProperties, ReactNode } from "react";
import Logo from "@assets/Logo_1781823781016.png";

/**
 * Exact-scale recreation of the Eggen Weed Control 3-part carbonless invoice.
 * All coordinates are in PDF points (1pt = 1/72in) measured from the client's
 * scan of the paper form (US Letter, 612x792pt). The page prints with 0.5in
 * margins, so scan coordinates are shifted by (OX, OY) to fit the printable
 * area. Part 1 (white) shows the Memo box; parts 2 & 3 (canary/pink) replace
 * Memo with the Unit/Chemical grid and add Material + payment rows above
 * Travel Instructions — those extra boxes print blank for handwriting.
 */

// The page prints with 0.25in (18pt) margins, so shifting scan coordinates by
// 18pt keeps every box at its original absolute position on the paper.
const OX = 18; // scan-x offset into the printable area
const OY = 18; // scan-y offset

const pt = (n: number) => `${n}pt`;

type V = Record<string, any>;

interface SheetProps {
  variant: "part1" | "part2" | "quote";
  values: V;
  number: number | string | undefined;
}

const LABEL: CSSProperties = {
  position: "absolute",
  fontFamily: "Helvetica, Arial, sans-serif",
  fontSize: "7.5pt",
  lineHeight: 1,
  color: "black",
  whiteSpace: "nowrap",
};

const VALUE: CSSProperties = {
  position: "absolute",
  fontFamily: "Helvetica, Arial, sans-serif",
  fontSize: "9pt",
  lineHeight: 1.1,
  color: "black",
  overflow: "hidden",
  whiteSpace: "nowrap",
};

function abs(x: number, y: number, w?: number, h?: number): CSSProperties {
  return {
    position: "absolute",
    left: pt(x - OX),
    top: pt(y - OY),
    ...(w != null ? { width: pt(w) } : {}),
    ...(h != null ? { height: pt(h) } : {}),
  };
}

function Box({ x, y, w, h, thick = false, children }: { x: number; y: number; w: number; h: number; thick?: boolean; children?: ReactNode }) {
  return (
    <div style={{ ...abs(x, y, w, h), border: `${thick ? 2.5 : 1}pt solid black`, boxSizing: "border-box" }}>
      {children}
    </div>
  );
}

function HLine({ x, y, w }: { x: number; y: number; w: number }) {
  return <div style={{ ...abs(x, y, w), borderTop: "1pt solid black", height: 0 }} />;
}

function VLine({ x, y, h }: { x: number; y: number; h: number }) {
  return <div style={{ ...abs(x, y, undefined, h), borderLeft: "1pt solid black", width: 0 }} />;
}

function Label({ x, y, children, size = 7.5 }: { x: number; y: number; children: ReactNode; size?: number }) {
  return <div style={{ ...LABEL, left: pt(x - OX), top: pt(y - OY), fontSize: `${size}pt` }}>{children}</div>;
}

function Value({ x, y, w, children, size = 9, wrap = false, h }: { x: number; y: number; w: number; children: ReactNode; size?: number; wrap?: boolean; h?: number }) {
  return (
    <div
      style={{
        ...VALUE,
        left: pt(x - OX),
        top: pt(y - OY),
        width: pt(w),
        fontSize: `${size}pt`,
        ...(wrap ? { whiteSpace: "pre-wrap", wordBreak: "break-word" } : {}),
        ...(h != null ? { height: pt(h) } : {}),
      }}
    >
      {children}
    </div>
  );
}

export function InvoicePrintSheet({ variant, values, number }: SheetProps) {
  const v = (k: string) => values[k] || "";
  const isPart2 = variant === "part2";
  const isQuote = variant === "quote";

  return (
    <div
      style={{
        position: "relative",
        width: pt(576), // 8in printable width at 0.25in margins
        height: pt(750), // just under the 10.5in printable height so a copy never spills
        fontFamily: "Helvetica, Arial, sans-serif",
        color: "black",
        overflow: "hidden",
      }}
    >
      {/* ===== Header ===== */}
      <img src={Logo} alt="Eggen Weed Control" style={{ ...abs(51, 24, 133), height: "auto" }} />
      <div style={{ ...abs(300, 34, 270), textAlign: "center", fontFamily: "'Bookman Old Style', Bookman, Georgia, serif", fontWeight: 700 }}>
        <div style={{ fontSize: "24pt", lineHeight: 1.15 }}>(602) 996-1000</div>
        <div style={{ fontSize: "15pt", lineHeight: 1.2 }}>7619 E. Greenway Rd., Ste. 800</div>
        <div style={{ fontSize: "15pt", lineHeight: 1.2 }}>Scottsdale, Arizona 85260</div>
      </div>
      <div style={{ ...abs(500, 18, 82), fontSize: "16pt", color: "#c0272d", textAlign: "right", fontFamily: "Helvetica, Arial, sans-serif" }}>
        {number ?? ""}
      </div>

      {/* ===== Row 1 left: Customer ===== */}
      <Box x={51} y={137} w={252} h={123} />
      <HLine x={51} y={168} w={252} />
      <HLine x={51} y={199} w={252} />
      <HLine x={51} y={230} w={252} />
      <VLine x={205} y={199} h={31} />
      <Label x={56} y={141}>Name</Label>
      <Value x={56} y={152} w={242}>{v("name")}</Value>
      <Label x={56} y={172}>Address</Label>
      <Value x={56} y={183} w={242}>{v("address")}</Value>
      <Label x={56} y={203}>City</Label>
      <Value x={56} y={214} w={144}>{v("city")}</Value>
      <Label x={209} y={203}>Zip</Label>
      <Value x={209} y={214} w={90}>{v("zip")}</Value>
      <Label x={56} y={234}>Home</Label>
      <Value x={56} y={245} w={72}>{v("homePhone")}</Value>
      <Label x={134} y={234}>Work</Label>
      <Value x={134} y={245} w={72}>{v("workPhone")}</Value>
      <Label x={213} y={234}>Other</Label>
      <Value x={213} y={245} w={86}>{v("otherPhone")}</Value>

      {/* ===== Row 1 right: Schedule Instructions ===== */}
      <Box x={314} y={137} w={256} h={123} />
      <HLine x={314} y={167} w={256} />
      <HLine x={314} y={198} w={256} />
      <HLine x={314} y={229} w={256} />
      <VLine x={405} y={167} h={93} />
      <VLine x={488} y={167} h={93} />
      <Label x={319} y={141}>Schedule Instructions</Label>
      <Label x={319} y={171}>Contact</Label>
      <Value x={319} y={182} w={82}>{v("scheduleContact")}</Value>
      <Label x={409} y={171}>Grid</Label>
      <Value x={409} y={182} w={75}>{v("grid")}</Value>
      <Label x={492} y={171}>Time</Label>
      <Value x={492} y={182} w={74}>{v("time")}</Value>
      <Label x={319} y={202}>{isQuote ? "Estimate" : "Quote"}</Label>
      <Value x={319} y={213} w={82}>{v("estimate")}</Value>
      <Label x={409} y={202}>I.D. #</Label>
      <Value x={409} y={213} w={75}>{v("idNumber")}</Value>
      <Label x={492} y={202}>Ratio</Label>
      <Value x={492} y={213} w={74}>{v("ratio")}</Value>
      <Label x={319} y={233}>Confirm</Label>
      <Value x={319} y={244} w={82}>{v("confirm")}</Value>
      <Label x={409} y={233}>Sales Person</Label>
      <Value x={409} y={244} w={75}>{v("salesPerson")}</Value>
      <Label x={492} y={233}>Treat Date</Label>
      <Value x={492} y={244} w={74}>{v("treatDate")}</Value>

      {/* ===== Row 2 left: Bill To ===== */}
      <Box x={51} y={270} w={252} h={120} />
      <HLine x={51} y={300} w={252} />
      <HLine x={51} y={331} w={252} />
      <HLine x={51} y={361} w={252} />
      <VLine x={205} y={331} h={30} />
      <Label x={56} y={274}>Bill To</Label>
      <Value x={56} y={285} w={242}>{v("billToName")}</Value>
      <Label x={56} y={304}>Address</Label>
      <Value x={56} y={315} w={242}>{v("billToAddress")}</Value>
      <Label x={56} y={335}>City</Label>
      <Value x={56} y={346} w={144}>{v("billToCity")}</Value>
      <Label x={209} y={335}>Zip</Label>
      <Value x={209} y={346} w={90}>{v("billToZip")}</Value>
      <Label x={56} y={365}>{isQuote ? "Home" : "Contact"}</Label>
      <Value x={56} y={376} w={72}>{v(isQuote ? "billToHome" : "billToContact")}</Value>
      <Label x={134} y={365}>Office</Label>
      <Value x={134} y={376} w={72}>{v("billToOffice")}</Value>
      <Label x={213} y={365}>{isQuote ? "Other" : "FAX"}</Label>
      <Value x={213} y={376} w={86}>{v("billToOther")}</Value>

      {/* ===== Row 2 right: Memo (part 1) or Unit grid (parts 2/3) ===== */}
      <Box x={314} y={268} w={256} h={129} />
      {!isPart2 ? (
        <>
          <Label x={319} y={273} size={7}>Memo</Label>
          <HLine x={314} y={294} w={256} />
          <HLine x={314} y={320} w={256} />
          <HLine x={314} y={346} w={256} />
          <HLine x={314} y={372} w={256} />
          <Value x={319} y={296} w={246} wrap h={98}>{v("memo")}</Value>
        </>
      ) : (
        <>
          {/* Header row: Unit | 10-8 | 10-7 | A.T. */}
          <HLine x={314} y={289} w={256} />
          <VLine x={377} y={268} h={21} />
          <VLine x={503} y={268} h={21} />
          <VLine x={440} y={268} h={129} />
          <Label x={319} y={272} size={7}>Unit</Label>
          <Label x={382} y={272} size={7}>10-8</Label>
          <Label x={445} y={272} size={7}>10-7</Label>
          <Label x={508} y={272} size={7}>A.T.</Label>
          {/* Body rows (handwritten) */}
          <HLine x={314} y={310} w={256} />
          <HLine x={314} y={332} w={256} />
          <HLine x={314} y={353} w={256} />
          <HLine x={314} y={375} w={256} />
          <Label x={319} y={293} size={7}>Name</Label>
          <Label x={445} y={293} size={7}>Name</Label>
          <Label x={319} y={314} size={7}>Gal.</Label>
          <Label x={445} y={314} size={7}>Chem.</Label>
        </>
      )}

      {/* ===== Check / P.O. / Total ===== */}
      <Box x={51} y={397} w={253} h={71} />
      <HLine x={51} y={432} w={253} />
      <VLine x={128} y={432} h={36} />
      <VLine x={202} y={432} h={36} />
      <Label x={56} y={436}>Check #</Label>
      <Value x={56} y={448} w={66}>{v("checkNumber")}</Value>
      <Label x={134} y={436}>P.O. #</Label>
      <Value x={134} y={448} w={62}>{v("poNumber")}</Value>
      <Label x={208} y={436}>Total</Label>
      <Value x={208} y={448} w={90}>{v("total")}</Value>

      {/* ===== Payable upon receipt / Thank you (invoice) or Quotation title (quote) ===== */}
      {isQuote ? (
        <div
          style={{
            ...abs(60, 468, 290),
            fontFamily: "'Bookman Old Style', Bookman, Georgia, serif",
            fontWeight: 700,
            fontSize: "36pt",
            lineHeight: 1.1,
          }}
        >
          Quotation
        </div>
      ) : (
        <div style={{ ...abs(60, 472, 235), textAlign: "center", fontFamily: "'Bookman Old Style', Bookman, Georgia, serif", fontWeight: 700 }}>
          <div style={{ fontSize: "17pt", lineHeight: 1.1 }}>Payable upon receipt</div>
          <div style={{ fontSize: "24pt", lineHeight: 1.1 }}>Thank you.</div>
        </div>
      )}

      {/* ===== Special Instructions (thick border) ===== */}
      <Box x={314} y={402} w={256} h={114} thick />
      <Label x={321} y={408}>Special Instructions</Label>
      <Value x={321} y={420} w={242} wrap h={90}>{v("specialInstructions")}</Value>

      {/* ===== Job Description ===== */}
      <Box x={51} y={518} w={519} h={isPart2 ? 145 : 205} />
      <Label x={56} y={523}>Job Description</Label>
      <Value x={56} y={535} w={509} wrap h={isPart2 ? 122 : 182}>{v("jobDescription")}</Value>

      {isPart2 && (
        <>
          {/* ===== Material row (handwritten) ===== */}
          <Box x={51} y={663} w={519} h={30} />
          <VLine x={107} y={663} h={30} />
          <VLine x={166} y={663} h={30} />
          <VLine x={224} y={663} h={30} />
          <VLine x={283} y={663} h={30} />
          <VLine x={341} y={663} h={30} />
          <Label x={55} y={667} size={7}>A.T.</Label>
          <Label x={111} y={667} size={7}>Material</Label>
          <Label x={170} y={667} size={7}>Material</Label>
          <Label x={229} y={667} size={7}>Material</Label>
          <Label x={287} y={667} size={7}>Material</Label>
          <Label x={345} y={667} size={7}>Notes</Label>

          {/* ===== Payment tracking row (handwritten) ===== */}
          <Box x={51} y={693} w={519} h={30} />
          <VLine x={109} y={693} h={30} />
          <VLine x={167} y={693} h={30} />
          <VLine x={225} y={693} h={30} />
          <VLine x={284} y={693} h={30} />
          <VLine x={340} y={693} h={30} />
          <VLine x={397} y={693} h={30} />
          <VLine x={455} y={693} h={30} />
          <VLine x={513} y={693} h={30} />
          <Label x={55} y={697} size={7}>S.J. Acct. #</Label>
          <Label x={113} y={697} size={7}>Date Paid</Label>
          <Label x={171} y={697} size={7}>Check #</Label>
          <Label x={229} y={697} size={7}>Amount Paid</Label>
          <Label x={288} y={697} size={7}>Balance Due</Label>
          <Label x={344} y={697} size={7}>Date Paid</Label>
          <Label x={401} y={697} size={7}>Check #</Label>
          <Label x={459} y={697} size={7}>Amount Paid</Label>
          <Label x={517} y={697} size={7}>Balance Due</Label>
        </>
      )}

      {/* ===== Travel Instructions ===== */}
      <Box x={51} y={723} w={519} h={37} />
      <Label x={55} y={728}>Travel Instructions</Label>
      <Value x={130} y={735} w={430}>{v("travelInstructions")}</Value>
    </div>
  );
}
