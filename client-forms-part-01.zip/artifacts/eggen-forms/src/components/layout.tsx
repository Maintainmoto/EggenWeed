import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { FileText, FileSignature, LayoutDashboard, LogOut } from "lucide-react";
import Logo from "@assets/Logo_1781823781016.png";

import { Button } from "@/components/ui/button";
import { useLogout, getGetAuthStatusQueryKey } from "@workspace/api-client-react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const queryClient = useQueryClient();

  const logoutMutation = useLogout({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAuthStatusQueryKey() });
      },
    },
  });

  return (
    <div className="min-h-screen flex w-full bg-background print:bg-white print:block">
      {/* Sidebar - hidden on print */}
      <aside className="w-64 border-r bg-sidebar text-sidebar-foreground flex-shrink-0 no-print">
        <div className="p-6">
          <Link href="/">
            <img src={Logo} alt="Eggen Weed Control" className="w-full h-auto object-contain cursor-pointer bg-white p-2 rounded-md mb-8" />
          </Link>
          <nav className="space-y-2">
            <Link href="/" className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${location === '/' ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}>
              <LayoutDashboard size={18} />
              Dashboard
            </Link>
            <Link href="/invoices/new" className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${location === '/invoices/new' ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}>
              <FileText size={18} />
              New Invoice
            </Link>
            <Link href="/quotes/new" className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${location === '/quotes/new' ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}>
              <FileSignature size={18} />
              New Quote
            </Link>
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden print:w-full">
        {/* Top header - hidden on print */}
        <header className="h-14 border-b bg-card flex items-center justify-between px-6 shrink-0 no-print sticky top-0 z-10">
          <h1 className="font-medium">Eggen Weed Control Forms</h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Sign Out
          </Button>
        </header>

        <div className="flex-1 overflow-y-auto print:overflow-visible">
          <div className="p-6 max-w-[1200px] mx-auto print:p-0 print:max-w-none">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
