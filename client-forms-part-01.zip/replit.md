# Eggen Weed Control Forms

A digital forms app for Eggen Weed Control (Scottsdale, AZ). Office staff create, save, and reprint Invoices and Quotations, replacing the company's paper carbon-copy forms.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm --filter @workspace/eggen-forms run dev` — run the web app (run via workflows, not directly)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string; `SESSION_SECRET` — signs auth cookies; `APP_PASSWORD` — shared office login password

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Web: React + Vite, wouter (routing), TanStack Query, react-hook-form, Tailwind, shadcn/ui
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- API contract (source of truth): `lib/api-spec/openapi.yaml`
- DB schema (source of truth): `lib/db/src/schema/documents.ts`
- API routes: `artifacts/api-server/src/routes/documents.ts` (registered in `routes/index.ts`)
- Auth: `artifacts/api-server/src/routes/auth.ts` (login/logout/me + `requireAuth` middleware); web login at `artifacts/eggen-forms/src/pages/login.tsx`, gated by `AuthGate` in `App.tsx`
- Web app: `artifacts/eggen-forms/src/` — `pages/dashboard.tsx`, `pages/document-editor.tsx` (shared by invoice + quote), `components/layout.tsx`
- Generated API hooks/Zod: `lib/api-client-react`, `lib/api-zod`
- Theme + print CSS: `artifacts/eggen-forms/src/index.css`

## Architecture decisions

- Single shared `documents` table for both invoices and quotes, distinguished by a `type` column ("invoice" | "quote"). Almost all form fields are nullable text so the same model backs both forms.
- Document numbers are server-assigned, never user-editable: invoices count up from 40000, quotes from 1000. The UI displays the upcoming number via `GET /api/documents/next-number` (advisory only); the committed number is assigned on create.
- Number assignment is atomic: create runs in a transaction guarded by a per-type Postgres advisory lock (`pg_advisory_xact_lock`), with a unique index on `(type, doc_number)` as a safety net against duplicates.
- Timestamps are serialized to ISO strings before Zod response parsing (Drizzle returns `Date` objects; the generated schemas expect strings).
- One shared `DocumentEditor` component renders both forms; the `type` prop drives the heading (INVOICE/QUOTATION) and quote-only signature footer.
- Auth is a single shared office password (no per-user accounts). Login compares the submitted password (timing-safe) against the `APP_PASSWORD` secret and sets a signed, httpOnly session cookie signed with `SESSION_SECRET` (via `cookie-parser` — no session store, no new deps). `requireAuth` gates the documents router; `/api/healthz` and `/api/auth/*` stay public. Cookie is `secure` only in production, and `trust proxy` is enabled so secure cookies work behind Replit's reverse proxy.

## Product

- Dashboard: invoice/quote counts, last-used numbers, and a recent-documents table with edit/delete.
- Invoice and Quote editors: faithful on-screen recreation of the paper carbon-copy layout (customer, schedule instructions, bill-to, memo, special instructions, job description, travel instructions). Quote adds Print Name / Signature / Date.
- Save persists the document; existing documents reload for editing and reprinting.
- Print: each form prints to a single US Letter page in portrait orientation (`@page { size: letter portrait }`), hiding all app chrome.

## Eggen Operations (eggen-ops)

- Second web artifact (`artifacts/eggen-ops`, previewPath `/eggen-ops/`) that rebuilds the client's FileMaker solution natively. FileMaker is design-reference only.
- Quote → Job: a job is created only on the transition INTO `Accepted` with a `treatDate` (on create if a quote is created already Accepted, or on the PATCH that flips it to Accepted). It inserts a matching `Open` job carrying that date plus the quote's property/address/contact/description fields, in the same transaction. No `treatDate` → no job. Re-saving an already-Accepted quote does nothing (no duplicates). (Job and Quote both have a `treatDate` column.)
- Quote un-accept cleanup: jobs carry a nullable `quoteId` FK (`jobsTable.quoteId`) set when the job is created from a quote. Moving an Accepted quote back to Draft/Sent/Rejected deletes the matching job **only while it is still `Open`** — jobs already Scheduled/Complete/Invoiced represent real downstream work and are never dragged backward or deleted. Re-accepting afterward recreates the job (no duplicates because the prior one was removed). `quoteId` is exposed in the jobs API response so the invoice → job → quote → property chain is traceable.
- Form field auto-fill/filtering (driven by `FieldSpec` hooks in `components/crud.tsx`): a relation field's `onSelect(id)` merges extra values into the form (e.g. Jobs: picking a Property fills address/city/unit/contact), and `optionsFor(values)` filters a relation's dropdown from current form values (e.g. Quotes: Property list is limited to the selected customer's properties; changing the customer clears the chosen property via the customer field's `onSelect`). `quickCreateInitial(values)` seeds a relation's "+" quick-create dialog from the parent form (e.g. Quotes: opening "New Property" after picking a customer pre-fills that customer into the new property).
- Five entities backed by `/api/ops/*`: Customers, Properties, Quotes, Jobs, Invoices, plus `GET /api/ops/stats` for the dashboard. Backend routes live in `artifacts/api-server/src/routes/ops.ts`.
- Shares the same office-password auth as the Forms app (`APP_PASSWORD` / `SESSION_SECRET`).
- Frontend is built from shared generic CRUD primitives in `src/components/crud.tsx` (`EntityFormDialog`, `CrudList`, `CrudDetail`, `StatusBadge`) driven by per-page `FieldSpec[]` configs; one page file per entity in `src/pages/`.
- Relations store the FK id plus a denormalized name (e.g. `customerId` + `customerName`) where the schema has a name column; ID-only relations (jobs→property, invoices→job/quote) send only the FK.
- Invoice `balanceDue` is server-computed (`total - amountPaid`) and is display-only — never sent on create/update.
- Invoices carry a contact/bill-to block (address/city/state/zip/phone/email) used by the printable invoice and Email action. Selecting a Quote on the invoice form auto-fills these from the quote (`onSelect`). Invoice routes are mounted at `/api/invoices` (not `/api/ops/*`).
- Invoice detail has Print + Email actions. The printable invoice mirrors the Eggen Weed Control Forms paper invoice layout (shared visual: logo header, company address block, "INVOICE" + boxed "No.", bordered Bill To / Invoice Information boxes, Total/Amount Paid/Balance Due row, "Payable upon receipt — Thank you." footer). `InvoiceDocument` holds the layout; `InvoicePrintView` wraps it in `print-only hidden` for `window.print()` (US Letter portrait; editable `CrudDetail` wrapped in `no-print`).
- Quote detail has the same Print + Email actions as invoices (same PDF-download-then-mailto flow). The printable quote mirrors the paper layout titled "QUOTATION" + boxed "No." = quote id, bordered Bill To / Quote Information (Estimate/Treat/Status/Sales/PO #) boxes, optional Job Description box, a Total row, a Print Name / Signature / Date signature block, and a thank-you footer. `QuoteDocument`/`QuotePrintView`/`handleEmail`/`emailHref` in `pages/quotes.tsx` mirror the invoice implementations (saves `Quote-<id>.pdf`).
- Email action generates a PDF client-side and downloads it, then opens a `mailto:` draft (the office user attaches the downloaded PDF — a `mailto:` link cannot auto-attach files; no server email send). PDF is rasterized from an off-screen full-width (816px) render of `InvoiceDocument` via `html2canvas-pro` (oklch-safe for Tailwind v4) → `jsPDF` (letter, 0.5in margins), saved as `Invoice-<id>.pdf`. The logo asset is imported from `@assets/Logo_1781823781016.png`.
- Job lifecycle: jobs move through a fixed status set Open → Scheduled → Complete → Invoiced (UI dropdown via `JOB_STATUS_OPTIONS` in `jobs.tsx`, color-coded). New jobs default to `Open` and the status is enforced server-side: `POST/PATCH /api/ops/jobs` normalize case and reject unknown values via `normalizeJobStatus` in `ops.ts`. Transitions are driven by route scheduling and invoicing, not hand-set by staff in normal flow.
- Ready to Invoice: dedicated page (`pages/ready-to-invoice.tsx`, route `/ready-to-invoice`, sidebar nav between Jobs and Invoices) that lists every job in `Complete` status (i.e. done but not yet invoiced). Staff multi-select jobs (select-all + per-row checkboxes), optionally set a per-row Total, then "Create N Invoices" creates one invoice per selected job via `useCreateInvoice` (jobId, customerName looked up from the job's property, total, paymentStatus "Not Sent", invoiceDate today). Each create flips its job to `Invoiced` server-side, so invoiced jobs drop off the list; on success it invalidates jobs+invoices queries and routes to `/invoices`.
- Route → job wiring: `route_sheet_stops.jobId` (nullable FK→jobs) links each stop to a job. The route builder (`route-sheet-editor.tsx`) only offers OPEN jobs to add as stops, looking up property fields (grid/phone/address/name) from the linked job's property. Saving a route runs `scheduleJobs(tx, stops)` which bumps linked jobs to `Scheduled` (only from null/Open/Scheduled, so it never drags Complete/Invoiced backward). `POST /api/ops/route-sheets/{id}/complete` ("Mark Route Complete" button) sets linked jobs to `Complete` (skips already-Invoiced). Creating an invoice with a `jobId` flips that job to `Invoiced` (invoice create runs in a transaction). Dashboard open-jobs count excludes `Scheduled`.
- Route reference number: each route sheet gets a server-assigned sequential `routeNumber` (counts up from 1), shown alongside the date to identify a route (list "Route #" column, editor heading, print header). Assigned atomically on create via `pg_advisory_xact_lock` + a unique index on `route_number` (same pattern as document numbers); never user-editable, never reassigned on update.
- Daily Route Sheet: pick a date + unit + sprayer(s), add property stops, save, and print a sheet mirroring the paper "DAILY ROUTE SHEET". Backed by `route_sheets` (header) + `route_sheet_stops` (cascade FK to route sheet, FK to property) in `lib/db/src/schema/route-sheets.ts`, routes at `/api/route-sheets` in `ops.ts` (note: the route-sheet endpoints are mounted at `/api/route-sheets`, unlike most ops endpoints which sit under `/api/ops/*`), pages `pages/route-sheets.tsx` (list) + `pages/route-sheet-editor.tsx` (builder + print). Stops denormalize property fields (name, address, grid, phone, customerName) at save time; per-row `serviceType` (default "SPOT"), `et`, `idNumber` are editable. Create/update run in a transaction; update replaces all stops. Stops are ordered by `position`. JOB NAME on print = `serviceType - propertyName - address`. Operational handwritten columns (Start/End, Mileage, Rig Hours) print blank for the crew to fill in by hand.

## User preferences

- Printing must be US Letter, portrait orientation.
- Forms must mirror the client's existing paper carbon-copy layouts.
- Invoice payment status must be a fixed dropdown with EXACTLY these values: "Not Sent", "Sent", "Partially Paid", "Paid" (color-coded).

## Gotchas

- Restart the `artifacts/api-server` workflow after editing routes — dev runs a built bundle, so route changes are not hot-reloaded.
- After changing `lib/api-spec/openapi.yaml`, run codegen before relying on new hooks/schemas. Do not change the OpenAPI `info.title` — it controls generated filenames.
- After changing `lib/db` schema, run `pnpm run typecheck:libs` before leaf artifact checks.
- In artifact JSX, do NOT write explicit generic type arguments on a component element (e.g. `<CrudList<Customer> .../>`). The Replit cartographer dev babel plugin injects metadata attributes between the name and the `<` and fails to parse it. Drop the generic and let TypeScript infer it from props.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
