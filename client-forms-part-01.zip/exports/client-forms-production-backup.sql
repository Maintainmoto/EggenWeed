-- Client Forms production database backup
-- PostgreSQL schema and data; generated read-only from the live production database.
-- Restore into an empty PostgreSQL database with: psql -f client-forms-production-backup.sql
SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
BEGIN;

CREATE SEQUENCE public."customers_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."documents_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."invoices_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."jobs_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."properties_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."quotes_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."route_sheet_stops_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;
CREATE SEQUENCE public."route_sheets_id_seq" AS bigint INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1 NO CYCLE;

CREATE TABLE public."customers" (
  "id" integer DEFAULT nextval('customers_id_seq'::regclass) NOT NULL,
  "customer_name" text,
  "customer_type" text,
  "contact_name" text,
  "contact_number" text,
  "address" text,
  "city" text,
  "state" text,
  "zip" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  "email" text
);

CREATE TABLE public."documents" (
  "id" integer DEFAULT nextval('documents_id_seq'::regclass) NOT NULL,
  "type" text NOT NULL,
  "doc_number" integer NOT NULL,
  "name" text,
  "address" text,
  "city" text,
  "zip" text,
  "home_phone" text,
  "work_phone" text,
  "other_phone" text,
  "bill_to_name" text,
  "bill_to_address" text,
  "bill_to_city" text,
  "bill_to_zip" text,
  "bill_to_home" text,
  "bill_to_office" text,
  "bill_to_other" text,
  "bill_to_contact" text,
  "schedule_contact" text,
  "grid" text,
  "time" text,
  "estimate" text,
  "id_number" text,
  "ratio" text,
  "confirm" text,
  "sales_person" text,
  "treat_date" text,
  "memo" text,
  "special_instructions" text,
  "check_number" text,
  "po_number" text,
  "total" text,
  "job_description" text,
  "travel_instructions" text,
  "print_name" text,
  "signature_date" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE public."invoices" (
  "id" integer DEFAULT nextval('invoices_id_seq'::regclass) NOT NULL,
  "job_id" integer,
  "quote_id" integer,
  "customer_name" text,
  "total" double precision,
  "amount_paid" double precision,
  "payment_status" text,
  "check_number" text,
  "invoice_date" date,
  "due_date" date,
  "date_paid" date,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  "address" text,
  "city" text,
  "state" text,
  "zip" text,
  "phone" text,
  "email" text
);

CREATE TABLE public."jobs" (
  "id" integer DEFAULT nextval('jobs_id_seq'::regclass) NOT NULL,
  "property_id" integer,
  "name" text,
  "address" text,
  "city" text,
  "contact" text,
  "acreage" double precision,
  "job_description" text,
  "schedule_instructions" text,
  "special_instructions" text,
  "travel_instructions" text,
  "job_status" text,
  "chemicals" text,
  "gallons" text,
  "additional_time" text,
  "notes" text,
  "tech_name_1" text,
  "tech_name_2" text,
  "unit" text,
  "time" text,
  "arrival_time" text,
  "ten_eight" text,
  "ten_seven" text,
  "confirm" date,
  "treat_date" date,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  "quote_id" integer,
  "total" double precision
);

CREATE TABLE public."properties" (
  "id" integer DEFAULT nextval('properties_id_seq'::regclass) NOT NULL,
  "customer_id" integer,
  "customer_name" text,
  "name" text,
  "street_address" text,
  "unit" text,
  "city" text,
  "state" text,
  "zip" text,
  "phone" text,
  "contact" text,
  "sales_person" text,
  "status" text,
  "field" text,
  "grid" text,
  "acreage" double precision,
  "ratio" double precision,
  "invoice_number" integer,
  "estimate_date" date,
  "first_service_date" date,
  "next_service_date" date,
  "confirm" text,
  "time" text,
  "job_description" text,
  "quote_description" text,
  "special_instructions" text,
  "travel_instructions" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE public."quotes" (
  "id" integer DEFAULT nextval('quotes_id_seq'::regclass) NOT NULL,
  "property_id" integer,
  "customer_id" integer,
  "customer_name" text,
  "property_name" text,
  "name" text,
  "address" text,
  "city" text,
  "state" text,
  "zip" text,
  "phone_number" text,
  "email" text,
  "contact" text,
  "bill_to_address" text,
  "bill_to_city" text,
  "bill_to_zip" text,
  "bill_to_phone" text,
  "check_number" text,
  "id_number" text,
  "po_number" text,
  "grid" text,
  "job_description" text,
  "memo" text,
  "schedule_instructions" text,
  "special_instructions" text,
  "sales_person" text,
  "status" text,
  "ratio" double precision,
  "total" double precision,
  "time" text,
  "confirm" date,
  "estimate_date" date,
  "treat_date" date,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);

CREATE TABLE public."route_sheet_stops" (
  "id" integer DEFAULT nextval('route_sheet_stops_id_seq'::regclass) NOT NULL,
  "route_sheet_id" integer NOT NULL,
  "property_id" integer,
  "position" integer DEFAULT 0 NOT NULL,
  "service_type" text,
  "et" text,
  "property_name" text,
  "customer_name" text,
  "address" text,
  "grid" text,
  "id_number" text,
  "phone" text,
  "job_id" integer
);

CREATE TABLE public."route_sheets" (
  "id" integer DEFAULT nextval('route_sheets_id_seq'::regclass) NOT NULL,
  "date" date,
  "unit" text,
  "sprayer" text,
  "sprayer_2" text,
  "type_of_route" text,
  "rig_hours" text,
  "notes" text,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  "route_number" integer
);

ALTER TABLE ONLY public."customers" ADD CONSTRAINT "customers_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."documents" ADD CONSTRAINT "documents_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."invoices" ADD CONSTRAINT "invoices_job_id_jobs_id_fk" FOREIGN KEY (job_id) REFERENCES jobs(id);
ALTER TABLE ONLY public."invoices" ADD CONSTRAINT "invoices_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."invoices" ADD CONSTRAINT "invoices_quote_id_quotes_id_fk" FOREIGN KEY (quote_id) REFERENCES quotes(id);
ALTER TABLE ONLY public."jobs" ADD CONSTRAINT "jobs_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."jobs" ADD CONSTRAINT "jobs_property_id_properties_id_fk" FOREIGN KEY (property_id) REFERENCES properties(id);
ALTER TABLE ONLY public."jobs" ADD CONSTRAINT "jobs_quote_id_quotes_id_fk" FOREIGN KEY (quote_id) REFERENCES quotes(id);
ALTER TABLE ONLY public."properties" ADD CONSTRAINT "properties_customer_id_customers_id_fk" FOREIGN KEY (customer_id) REFERENCES customers(id);
ALTER TABLE ONLY public."properties" ADD CONSTRAINT "properties_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."quotes" ADD CONSTRAINT "quotes_customer_id_customers_id_fk" FOREIGN KEY (customer_id) REFERENCES customers(id);
ALTER TABLE ONLY public."quotes" ADD CONSTRAINT "quotes_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."quotes" ADD CONSTRAINT "quotes_property_id_properties_id_fk" FOREIGN KEY (property_id) REFERENCES properties(id);
ALTER TABLE ONLY public."route_sheet_stops" ADD CONSTRAINT "route_sheet_stops_job_id_jobs_id_fk" FOREIGN KEY (job_id) REFERENCES jobs(id);
ALTER TABLE ONLY public."route_sheet_stops" ADD CONSTRAINT "route_sheet_stops_pkey" PRIMARY KEY (id);
ALTER TABLE ONLY public."route_sheet_stops" ADD CONSTRAINT "route_sheet_stops_property_id_properties_id_fk" FOREIGN KEY (property_id) REFERENCES properties(id);
ALTER TABLE ONLY public."route_sheet_stops" ADD CONSTRAINT "route_sheet_stops_route_sheet_id_route_sheets_id_fk" FOREIGN KEY (route_sheet_id) REFERENCES route_sheets(id) ON DELETE CASCADE;
ALTER TABLE ONLY public."route_sheets" ADD CONSTRAINT "route_sheets_pkey" PRIMARY KEY (id);

CREATE UNIQUE INDEX documents_type_doc_number_unique ON public.documents USING btree (type, doc_number);
CREATE UNIQUE INDEX route_sheets_route_number_unique ON public.route_sheets USING btree (route_number);

SELECT pg_catalog.setval('public."documents_id_seq"', 10, true);

COMMIT;
