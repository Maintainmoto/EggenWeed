import {
  pgTable,
  serial,
  integer,
  text,
  doublePrecision,
  date,
  timestamp,
} from "drizzle-orm/pg-core";
import { propertiesTable } from "./properties";
import { quotesTable } from "./quotes";

export const jobsTable = pgTable("jobs", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => propertiesTable.id),
  quoteId: integer("quote_id").references(() => quotesTable.id),
  name: text("name"),
  address: text("address"),
  city: text("city"),
  contact: text("contact"),
  acreage: doublePrecision("acreage"),
  jobDescription: text("job_description"),
  scheduleInstructions: text("schedule_instructions"),
  specialInstructions: text("special_instructions"),
  travelInstructions: text("travel_instructions"),
  jobStatus: text("job_status"),
  total: doublePrecision("total"),
  chemicals: text("chemicals"),
  gallons: text("gallons"),
  additionalTime: text("additional_time"),
  notes: text("notes"),
  techName1: text("tech_name_1"),
  techName2: text("tech_name_2"),
  unit: text("unit"),
  time: text("time"),
  arrivalTime: text("arrival_time"),
  tenEight: text("ten_eight"),
  tenSeven: text("ten_seven"),
  confirm: date("confirm", { mode: "string" }),
  treatDate: date("treat_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type Job = typeof jobsTable.$inferSelect;
export type InsertJob = typeof jobsTable.$inferInsert;
