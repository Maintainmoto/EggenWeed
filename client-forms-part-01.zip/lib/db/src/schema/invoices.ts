import {
  pgTable,
  serial,
  integer,
  text,
  doublePrecision,
  date,
  timestamp,
} from "drizzle-orm/pg-core";
import { jobsTable } from "./jobs";
import { quotesTable } from "./quotes";

export const invoicesTable = pgTable("invoices", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").references(() => jobsTable.id),
  quoteId: integer("quote_id").references(() => quotesTable.id),
  customerName: text("customer_name"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  phone: text("phone"),
  email: text("email"),
  total: doublePrecision("total"),
  amountPaid: doublePrecision("amount_paid"),
  paymentStatus: text("payment_status"),
  checkNumber: text("check_number"),
  invoiceDate: date("invoice_date", { mode: "string" }),
  dueDate: date("due_date", { mode: "string" }),
  datePaid: date("date_paid", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type Invoice = typeof invoicesTable.$inferSelect;
export type InsertInvoice = typeof invoicesTable.$inferInsert;
