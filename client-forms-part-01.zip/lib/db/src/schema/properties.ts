import {
  pgTable,
  serial,
  integer,
  text,
  doublePrecision,
  date,
  timestamp,
} from "drizzle-orm/pg-core";
import { customersTable } from "./customers";

export const propertiesTable = pgTable("properties", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").references(() => customersTable.id),
  customerName: text("customer_name"),
  name: text("name"),
  streetAddress: text("street_address"),
  unit: text("unit"),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  phone: text("phone"),
  contact: text("contact"),
  salesPerson: text("sales_person"),
  status: text("status"),
  field: text("field"),
  grid: text("grid"),
  acreage: doublePrecision("acreage"),
  ratio: doublePrecision("ratio"),
  invoiceNumber: integer("invoice_number"),
  estimateDate: date("estimate_date", { mode: "string" }),
  firstServiceDate: date("first_service_date", { mode: "string" }),
  nextServiceDate: date("next_service_date", { mode: "string" }),
  confirm: text("confirm"),
  time: text("time"),
  jobDescription: text("job_description"),
  quoteDescription: text("quote_description"),
  specialInstructions: text("special_instructions"),
  travelInstructions: text("travel_instructions"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type Property = typeof propertiesTable.$inferSelect;
export type InsertProperty = typeof propertiesTable.$inferInsert;
