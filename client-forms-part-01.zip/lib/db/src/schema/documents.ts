import { pgTable, serial, integer, text, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const documentsTable = pgTable(
  "documents",
  {
    id: serial("id").primaryKey(),
    type: text("type").notNull(),
    docNumber: integer("doc_number").notNull(),
    name: text("name"),
    address: text("address"),
    city: text("city"),
    zip: text("zip"),
    homePhone: text("home_phone"),
    workPhone: text("work_phone"),
    otherPhone: text("other_phone"),
    billToName: text("bill_to_name"),
    billToAddress: text("bill_to_address"),
    billToCity: text("bill_to_city"),
    billToZip: text("bill_to_zip"),
    billToHome: text("bill_to_home"),
    billToOffice: text("bill_to_office"),
    billToOther: text("bill_to_other"),
    billToContact: text("bill_to_contact"),
    scheduleContact: text("schedule_contact"),
    grid: text("grid"),
    time: text("time"),
    estimate: text("estimate"),
    idNumber: text("id_number"),
    ratio: text("ratio"),
    confirm: text("confirm"),
    salesPerson: text("sales_person"),
    treatDate: text("treat_date"),
    memo: text("memo"),
    specialInstructions: text("special_instructions"),
    checkNumber: text("check_number"),
    poNumber: text("po_number"),
    total: text("total"),
    jobDescription: text("job_description"),
    travelInstructions: text("travel_instructions"),
    printName: text("print_name"),
    signatureDate: text("signature_date"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("documents_type_doc_number_unique").on(table.type, table.docNumber),
  ],
);

export const insertDocumentSchema = createInsertSchema(documentsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documentsTable.$inferSelect;
