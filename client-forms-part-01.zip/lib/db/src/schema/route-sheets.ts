import {
  pgTable,
  serial,
  integer,
  text,
  date,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { propertiesTable } from "./properties";
import { jobsTable } from "./jobs";

export const routeSheetsTable = pgTable(
  "route_sheets",
  {
    id: serial("id").primaryKey(),
    routeNumber: integer("route_number"),
    date: date("date", { mode: "string" }),
    unit: text("unit"),
    sprayer: text("sprayer"),
    sprayer2: text("sprayer_2"),
    typeOfRoute: text("type_of_route"),
    rigHours: text("rig_hours"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    routeNumberUnique: uniqueIndex("route_sheets_route_number_unique").on(
      t.routeNumber,
    ),
  }),
);

export const routeSheetStopsTable = pgTable("route_sheet_stops", {
  id: serial("id").primaryKey(),
  routeSheetId: integer("route_sheet_id")
    .notNull()
    .references(() => routeSheetsTable.id, { onDelete: "cascade" }),
  propertyId: integer("property_id").references(() => propertiesTable.id),
  jobId: integer("job_id").references(() => jobsTable.id),
  position: integer("position").notNull().default(0),
  serviceType: text("service_type"),
  et: text("et"),
  propertyName: text("property_name"),
  customerName: text("customer_name"),
  address: text("address"),
  grid: text("grid"),
  idNumber: text("id_number"),
  phone: text("phone"),
});

export type RouteSheet = typeof routeSheetsTable.$inferSelect;
export type InsertRouteSheet = typeof routeSheetsTable.$inferInsert;
export type RouteSheetStop = typeof routeSheetStopsTable.$inferSelect;
export type InsertRouteSheetStop = typeof routeSheetStopsTable.$inferInsert;
