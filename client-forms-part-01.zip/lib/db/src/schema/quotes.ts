import {
  pgTable,
  serial,
  integer,
  text,
  doublePrecision,
  date,
  timestamp,
} from "drizzle-orm/pg-core";
import { customersTable } from "./customers";
import { propertiesTable } from "./properties";

export const quotesTable = pgTable("quotes", {
  id: serial("id").primaryKey(),
  propertyId: integer("property_id").references(() => propertiesTable.id),
  customerId: integer("customer_id").references(() => customersTable.id),
  customerName: text("customer_name"),
  propertyName: text("property_name"),
  name: text("name"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  phoneNumber: text("phone_number"),
  email: text("email"),
  contact: text("contact"),
  billToAddress: text("bill_to_address"),
  billToCity: text("bill_to_city"),
  billToZip: text("bill_to_zip"),
  billToPhone: text("bill_to_phone"),
  checkNumber: text("check_number"),
  idNumber: text("id_number"),
  poNumber: text("po_number"),
  grid: text("grid"),
  jobDescription: text("job_description"),
  memo: text("memo"),
  scheduleInstructions: text("schedule_instructions"),
  specialInstructions: text("special_instructions"),
  salesPerson: text("sales_person"),
  status: text("status"),
  ratio: doublePrecision("ratio"),
  total: doublePrecision("total"),
  time: text("time"),
  confirm: date("confirm", { mode: "string" }),
  estimateDate: date("estimate_date", { mode: "string" }),
  treatDate: date("treat_date", { mode: "string" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export type Quote = typeof quotesTable.$inferSelect;
export type InsertQuote = typeof quotesTable.$inferInsert;
